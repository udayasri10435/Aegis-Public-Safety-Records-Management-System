export type EvidenceCategory =
  | 'WEAPON_FIREARM'
  | 'NARCOTICS'
  | 'BIOLOGICAL_DNA'
  | 'DIGITAL_BWC_VIDEO'
  | 'CURRENCY'
  | 'PROPERTY_IMPOUND'
  | 'DOCUMENT_PHYSICAL';

export type CustodyAction =
  | 'RECOVERED_AT_SCENE'
  | 'INTAKE_TO_LOCKER'
  | 'CHECKED_OUT_LAB'
  | 'RETURNED_FROM_LAB'
  | 'CHECKED_OUT_COURT'
  | 'TRANSFERRED_CUSTODIAN'
  | 'FINAL_DISPOSITION_DESTROYED'
  | 'RELEASED_TO_OWNER';

export interface CustodyEvent {
  id: string;
  timestamp: string;
  action: CustodyAction;
  releasedByBadge: string;
  releasedByName: string;
  receivedByBadge: string;
  receivedByName: string;
  agencyDivision: string;
  purposeReason: string;
  tamperSealIntact: boolean;
  signatureVerificationId: string;
}

export interface EvidenceItem {
  trackingBarcode: string; // e.g. "EV-2026-9042-01"
  incidentId: string; // linked incident report
  category: EvidenceCategory;
  description: string;
  storageLockerLocation: string; // e.g. "Vault 1, Rack C, Locker 14"
  dateCollected: string;
  collectedByOfficer: string;
  collectedByBadge: string;
  currentCustodian: string;
  status: 'IN_VAULT' | 'OUT_AT_LAB' | 'IN_COURT' | 'RELEASED' | 'DISPOSED';
  sha256Hash: string; // cryptographic hash for digital file or tamper certificate
  notes?: string;
  chainOfCustody: CustodyEvent[];
  digitalAssetMeta?: {
    filename: string;
    fileSizeMb: number;
    durationSeconds?: number;
    mediaType: 'VIDEO' | 'AUDIO' | 'PHOTO' | 'DOCUMENT';
  };
}
