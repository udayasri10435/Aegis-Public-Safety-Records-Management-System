export type AuditActionType =
  | 'RECORD_VIEW'
  | 'RECORD_CREATE'
  | 'RECORD_EDIT'
  | 'SUPERVISOR_APPROVAL'
  | 'EVIDENCE_CUSTODY_TRANSFER'
  | 'CAD_TO_RMS_CONVERSION'
  | 'FOIA_REDACTION_APPLIED'
  | 'FOIA_PACKAGE_EXPORTED'
  | 'NCIC_CJIS_QUERY';

export interface CJISAuditLogEntry {
  id: string;
  timestamp: string;
  officerBadge: string;
  officerName: string;
  terminalIp: string;
  agencyDivision: string;
  action: AuditActionType;
  recordIdentifier: string;
  details: string;
  cjisClearanceLevel: 'LEVEL_1_OPERATOR' | 'LEVEL_2_OFFICER' | 'LEVEL_3_SUPERVISOR' | 'LEVEL_4_CHIEF_ADMIN';
}

export interface MasterPersonRecord {
  id: string;
  fullName: string;
  dob: string;
  ssnMasked: string;
  gender: string;
  race: string;
  address: string;
  phone: string;
  aliases: string[];
  cautionFlags: string[];
  linkedIncidents: {
    incidentId: string;
    role: string;
    date: string;
    agency: string;
  }[];
}

export interface MasterVehicleRecord {
  vin: string;
  plate: string;
  state: string;
  make: string;
  model: string;
  year: number;
  color: string;
  registeredOwner: string;
  isStolen: boolean;
  linkedIncidents: string[];
}
