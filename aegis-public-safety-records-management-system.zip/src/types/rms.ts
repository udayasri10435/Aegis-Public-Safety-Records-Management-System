export type AgencyType = 'POLICE' | 'FIRE' | 'EMS';

export type IncidentStatus = 'DRAFT' | 'SUPERVISOR_REVIEW' | 'APPROVED' | 'CJIS_SEALED';

export interface InvolvedPerson {
  id: string;
  role: 'VICTIM' | 'SUSPECT' | 'WITNESS' | 'REPORTING_PARTY' | 'PATIENT' | 'OTHER';
  fullName: string;
  dob: string;
  ssnMasked: string;
  phone: string;
  address: string;
  driverLicense?: string;
  cautionFlag?: string; // e.g., "Violent History", "DNR order", "Hearing Impaired"
  isJuvenile?: boolean;
}

export interface InvolvedVehicle {
  id: string;
  plate: string;
  state: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  color: string;
  isStolen?: boolean;
  notes?: string;
}

export interface FireModuleData {
  nfirsCode: string; // e.g. "111 - Building Fire"
  alarmTime: string;
  arrivalFirstUnit: string;
  controlledTime: string;
  clearedTime: string;
  propertyUse: string; // e.g. "419 - 1 or 2 family dwelling"
  detectorPresence: 'ALERTED' | 'NOT_ALERTED' | 'NONE' | 'UNDETERMINED';
  causeOfIgnition: string; // e.g. "Unattended cooking equipment"
  estimatedLossDollars: number;
  apparatusAssigned: string[]; // e.g. ["Engine 4", "Truck 1", "Battalion 1"]
  civilianInjuries: number;
  firefighterInjuries: number;
}

export interface EMSVitalSign {
  id: string;
  timestamp: string;
  bpSystolic: number;
  bpDiastolic: number;
  pulseRate: number;
  respiratoryRate: number;
  spo2Percent: number;
  gcsTotal: number; // Glasgow Coma Scale (3-15)
  bloodGlucose?: number;
}

export interface EMSModuleData {
  nemsisCode: string; // e.g. "I46.9 - Cardiac Arrest"
  chiefComplaint: string;
  initialAcuity: 'CRITICAL_RED' | 'EMERGENT_YELLOW' | 'NON_URGENT_GREEN' | 'EXPECTANT_BLACK';
  vitals: EMSVitalSign[];
  medicationsAdministered: {
    time: string;
    drug: string;
    dosage: string;
    route: string;
    giverBadge: string;
  }[];
  interventions: string[];
  transportHospital: string;
  triageCategory: string;
  dnrVerified: boolean;
}

export interface IncidentReport {
  id: string; // e.g. "2026-PD-10492"
  cadCallId?: string; // Linked CAD Dispatch
  agency: AgencyType;
  title: string;
  incidentType: string;
  codeNibrsOrClass: string; // NIBRS for PD, NFIRS for FD, NEMSIS for EMS
  status: IncidentStatus;
  occurredFrom: string;
  occurredTo?: string;
  reportedDate: string;
  locationAddress: string;
  zoneBeat: string;
  reportingOfficerName: string;
  reportingOfficerBadge: string;
  assignedUnit: string;
  supervisorName?: string;
  supervisorBadge?: string;
  supervisorApprovalDate?: string;
  narrativeText: string;
  persons: InvolvedPerson[];
  vehicles: InvolvedVehicle[];
  linkedEvidenceIds: string[];
  fireData?: FireModuleData;
  emsData?: EMSModuleData;
  confidentialFlag?: boolean;
}
