import { AgencyType } from './rms';

export type CADCallStatus = 'DISPATCHED' | 'EN_ROUTE' | 'ON_SCENE' | 'CLEARED_PENDING_RMS' | 'TRANSFERRED_TO_RMS';

export interface CADCallNote {
  timestamp: string;
  dispatcherId: string;
  noteText: string;
}

export interface CADDispatchedUnit {
  unitId: string;
  agency: AgencyType;
  dispatchedTime: string;
  enRouteTime?: string;
  onSceneTime?: string;
  clearedTime?: string;
  status: 'DISPATCHED' | 'EN_ROUTE' | 'ON_SCENE' | 'CLEARED';
}

export interface CADCallRecord {
  callId: string; // e.g. "CAD-26-8941"
  agency: AgencyType;
  priority: 1 | 2 | 3 | 4; // 1 = Life Threatening / Emergency
  callType: string; // e.g. "10-33 / SHOTS FIRED", "STRUCTURE FIRE", "CHEST PAIN / DELTA"
  cfsCode: string; // Call For Service code
  location: string;
  crossStreet?: string;
  sectorZone: string;
  callerName: string;
  callerPhone: string;
  createdTime: string;
  status: CADCallStatus;
  units: CADDispatchedUnit[];
  notes: CADCallNote[];
  rmsIncidentId?: string; // set when transferred
}
