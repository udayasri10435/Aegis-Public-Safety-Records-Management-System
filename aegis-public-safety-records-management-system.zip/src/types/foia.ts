export type FOIAStatus =
  | 'SUBMITTED'
  | 'IN_REDACTION'
  | 'LEGAL_REVIEW'
  | 'RELEASED_SANITIZED'
  | 'DENIED_EXEMPT';

export type StatutoryExemptionCode =
  | 'PRIVACY_552_B7C' // 5 U.S.C. § 552(b)(7)(C) - Personal Privacy & Unwarranted Invasion
  | 'JUVENILE_RECORD' // Statutory Juvenile Protection (Welfare & Inst. Code / FERPA)
  | 'CJIS_PII_SSN' // Criminal Justice Info / SSN / Financial / DL
  | 'ACTIVE_INVESTIGATION_552_B7A' // 5 U.S.C. § 552(b)(7)(A) - Interfere with Enforcement
  | 'HIPAA_MEDICAL_164' // 45 CFR § 164.512 - Protected Health Info / Patient Records
  | 'VICTIM_MARSY_LAW' // Marsy's Law / Domestic Violence victim safe harbor
  | 'TACTICAL_SECURITY_552_B7E'; // Techniques and procedures for law enforcement investigations

export interface RedactionMark {
  id: string;
  startIndex: number;
  endIndex: number;
  originalText: string;
  exemptionCode: StatutoryExemptionCode;
  exemptionLabel: string;
  redactedReplacementText: string; // e.g. "[REDACTED: 5 U.S.C. § 552(b)(7)(C) - PII]"
}

export interface FOIARequestRecord {
  requestId: string; // e.g. "FOIA-2026-0814"
  requestorName: string;
  requestorOrganization?: string;
  requestorEmail: string;
  requestDate: string;
  statutoryDueDate: string; // 10/20 business days statutory timeline
  targetIncidentId: string;
  recordTypeRequested: 'FULL_POLICE_REPORT' | 'CAD_911_AUDIO_LOG' | 'FIRE_INVESTIGATION' | 'EMS_RUN_REPORT';
  status: FOIAStatus;
  notes?: string;
  redactions: RedactionMark[];
  certificationSealNumber?: string;
  releasedDate?: string;
  complianceOfficerBadge?: string;
}
