/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RMSProvider, useRMS } from './context/RMSContext';
import { Header } from './components/Header';
import { IncidentsListView } from './components/IncidentsListView';
import { CADFeedView } from './components/CADFeedView';
import { EvidenceChainView } from './components/EvidenceChainView';
import { FOIAStudioView } from './components/FOIAStudioView';
import { MasterIndicesView } from './components/MasterIndicesView';
import { AuditLogView } from './components/AuditLogView';
import { IncidentFormModal } from './components/IncidentFormModal';
import { PrintableIncidentModal } from './components/PrintableIncidentModal';
import { IncidentReport } from './types/rms';

const RMSMainLayout: React.FC = () => {
  const { activeTab, setActiveTab, incidents } = useRMS();

  const [isNewIncidentOpen, setIsNewIncidentOpen] = useState(false);
  const [editingIncident, setEditingIncident] = useState<IncidentReport | null>(null);
  const [printingIncident, setPrintingIncident] = useState<IncidentReport | null>(null);
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setNotificationToast(msg);
    setTimeout(() => {
      setNotificationToast(null);
    }, 4000);
  };

  const handleIncidentCreatedFromCad = (incidentId: string) => {
    setActiveTab('incidents');
    const created = incidents.find(i => i.id === incidentId);
    if (created) {
      setEditingIncident(created);
    }
    showToast(`CAD Call successfully promoted to RMS Incident #${incidentId}`);
  };

  const handleSelectIncident = (incident: IncidentReport) => {
    setPrintingIncident(incident);
  };

  const handleSelectIncidentById = (incidentId: string) => {
    const found = incidents.find(i => i.id === incidentId);
    if (found) {
      setPrintingIncident(found);
    } else {
      setActiveTab('incidents');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Three-zone Top Bar Contract Header */}
      <Header
        onOpenNewIncidentModal={() => {
          setEditingIncident(null);
          setIsNewIncidentOpen(true);
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'incidents' && (
          <IncidentsListView
            onSelectIncident={handleSelectIncident}
            onOpenPrintModal={inc => setPrintingIncident(inc)}
            onOpenEditModal={inc => {
              setEditingIncident(inc);
              setIsNewIncidentOpen(true);
            }}
          />
        )}

        {activeTab === 'cad' && (
          <CADFeedView
            onIncidentCreatedFromCad={handleIncidentCreatedFromCad}
          />
        )}

        {activeTab === 'evidence' && <EvidenceChainView />}

        {activeTab === 'foia' && <FOIAStudioView />}

        {activeTab === 'master_indices' && (
          <MasterIndicesView onSelectIncidentById={handleSelectIncidentById} />
        )}

        {activeTab === 'audit_log' && <AuditLogView />}
      </main>

      {/* Operational Footer - Quiet, clean, no fake telemetry ticker */}
      <footer className="no-print border-t border-slate-900 bg-slate-950/80 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Aegis Public Safety Command Systems · Police (NIBRS) · Fire (NFIRS) · EMS (NEMSIS)
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            CJIS Policy v5.9 Standard Compliant · Encrypted Ledger
          </div>
        </div>
      </footer>

      {/* Incident Authoring/Editing Modal */}
      <IncidentFormModal
        isOpen={isNewIncidentOpen}
        onClose={() => {
          setIsNewIncidentOpen(false);
          setEditingIncident(null);
        }}
        initialIncident={editingIncident}
      />

      {/* Official Case Report Print / PDF Modal */}
      <PrintableIncidentModal
        incident={printingIncident}
        onClose={() => setPrintingIncident(null)}
      />

      {/* Notification Toast */}
      {notificationToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-cyan-600 text-white font-medium text-xs px-4 py-2.5 rounded-lg shadow-xl border border-cyan-400/40 flex items-center gap-2 animate-bounce">
          <span>{notificationToast}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <RMSProvider>
      <RMSMainLayout />
    </RMSProvider>
  );
}
