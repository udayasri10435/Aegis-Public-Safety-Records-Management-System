import { IncidentReport } from '../types/rms';
import { CADCallRecord } from '../types/cad';
import { EvidenceItem } from '../types/evidence';
import { FOIARequestRecord } from '../types/foia';
import { CJISAuditLogEntry, MasterPersonRecord, MasterVehicleRecord } from '../types/audit';

export const INITIAL_INCIDENTS: IncidentReport[] = [
  {
    id: '2026-PD-08942',
    cadCallId: 'CAD-26-44910',
    agency: 'POLICE',
    title: 'Commercial Armed Robbery & Fleeing Suspect',
    incidentType: 'ARMED ROBBERY (NIBRS 120)',
    codeNibrsOrClass: '120 - Robbery (Weapon Involved)',
    status: 'APPROVED',
    occurredFrom: '2026-09-28T21:40:00Z',
    occurredTo: '2026-09-28T22:15:00Z',
    reportedDate: '2026-09-28T21:42:15Z',
    locationAddress: '1420 North Meridian Boulevard, Suite 104',
    zoneBeat: 'Sector 4 / Beat 42',
    reportingOfficerName: 'Officer Marcus Vance',
    reportingOfficerBadge: 'PD-4819',
    assignedUnit: 'Unit 4-Adam-12',
    supervisorName: 'Sgt. Elena Rodriguez',
    supervisorBadge: 'PD-1102',
    supervisorApprovalDate: '2026-09-29T02:15:00Z',
    narrativeText: `On September 28, 2026, at approximately 21:41 hours, Unit 4-Adam-12 was dispatched to 1420 N Meridian Blvd (QuikStop Mart) regarding an armed robbery in progress.

Upon arrival at 21:45 hours, reporting party (Clerk: Dave Higgins, DOB: 04/12/1988) advised a male suspect entered wearing a black hooded sweatshirt and dark neoprene gloves, brandished a semi-automatic handgun (black finish), and demanded cash from drawer register #1 and #2. The clerk complied, turning over approximately $740.00 in mixed US currency.

Suspect fled westbound on foot toward 14th Avenue. BOLO was broadcast on Main Dispatch. Assisting unit 4-Boy-08 spotted an individual matching description discarding an item near the alleyway of 1380 N Meridian Blvd. Suspect identified as James R. Wallace (DOB: 06/22/1997, SSN: XXX-XX-4819) was detained without further incident. Discarded firearm, a Glock 19 9mm (SN: BWF-9024) loaded with 14 rounds 9mm Luger, was recovered from underneath a trash receptacle and logged under property chain EV-2026-8942-01.

Suspect was Mirandized at 22:04 hours by Officer Vance, transported to Central Holding, and booked on charges of Armed Robbery (PC § 211) and Carrying Concealed Firearm Without Permit. Body-Worn Camera footage from BWC Unit #04-Vance is archived under EV-2026-8942-02.`,
    persons: [
      {
        id: 'P-101',
        role: 'VICTIM',
        fullName: 'David Higgins',
        dob: '1988-04-12',
        ssnMasked: '***-**-6180',
        phone: '(555) 234-8891',
        address: '844 Elmwood Dr, Apt 2B',
        cautionFlag: 'Cooperative Store Employee'
      },
      {
        id: 'P-102',
        role: 'SUSPECT',
        fullName: 'James Richard Wallace',
        dob: '1997-06-22',
        ssnMasked: '***-**-4819',
        phone: '(555) 819-0021',
        address: '1120 South Oak Lane',
        driverLicense: 'DL-W8920194',
        cautionFlag: 'Violent History / Prior Weapons Offense'
      }
    ],
    vehicles: [
      {
        id: 'V-101',
        plate: '7XYZ890',
        state: 'CA',
        vin: '1HGCR2F83HA029184',
        make: 'Honda',
        model: 'Accord',
        year: 2017,
        color: 'Silver',
        isStolen: false,
        notes: 'Associated vehicle parked 1 block south, impounded for search warrant'
      }
    ],
    linkedEvidenceIds: ['EV-2026-8942-01', 'EV-2026-8942-02', 'EV-2026-8942-03'],
    confidentialFlag: false
  },
  {
    id: '2026-FD-01429',
    cadCallId: 'CAD-26-44892',
    agency: 'FIRE',
    title: 'Commercial 2nd Alarm Structure Fire - Warehouse',
    incidentType: 'BUILDING FIRE (NFIRS 111)',
    codeNibrsOrClass: '111 - Building Fire',
    status: 'APPROVED',
    occurredFrom: '2026-09-28T14:10:00Z',
    occurredTo: '2026-09-28T17:45:00Z',
    reportedDate: '2026-09-28T14:10:22Z',
    locationAddress: '3820 Industrial Parkway, Dock 4',
    zoneBeat: 'Battalion 2 / Fire District 7',
    reportingOfficerName: 'Captain Thomas Briggs',
    reportingOfficerBadge: 'FD-708',
    assignedUnit: 'Engine 7',
    supervisorName: 'Battalion Chief Arthur Reyes',
    supervisorBadge: 'FD-104',
    supervisorApprovalDate: '2026-09-28T19:30:00Z',
    narrativeText: `Initial dispatch for automatic commercial waterflow alarm and 911 reports of heavy black smoke pushing from roof eaves of a single-story tilt-up commercial storage warehouse (Apex Logistics Corp).

Engine 7 arrived on scene at 14:15 hours, initiated 360-degree size-up, and reported heavy smoke conditions from Division C. Requested 2nd alarm balance at 14:19 hours. Engine 7 stretched a 2.5-inch attack line through Sector A roll-up door. Truck 2 assigned vertical roof ventilation; roof team opened 4x8 inspection cuts, releasing pressurized heat and combustion gases.

Fire was brought under control at 15:32 hours. Primary and secondary searches completed with zero civilian or personnel trapped. Origin determined to be localized electrical short in lithium-ion forklift charging station in northeast corner (Sector B/C junction). Fire investigator Capt. Ruiz documented burn patterns, preserved circuit breaker panel under EV-2026-FD-01429-A. Facility power isolated by municipal utility.`,
    persons: [
      {
        id: 'P-201',
        role: 'REPORTING_PARTY',
        fullName: 'Carlos Mendoza',
        dob: '1979-11-03',
        ssnMasked: '***-**-3342',
        phone: '(555) 902-1847',
        address: '512 Harbor Way',
        cautionFlag: 'Facility Night Manager'
      }
    ],
    vehicles: [],
    linkedEvidenceIds: ['EV-2026-FD-01429-A'],
    fireData: {
      nfirsCode: '111 - Building Fire',
      alarmTime: '2026-09-28T14:10:22Z',
      arrivalFirstUnit: '2026-09-28T14:15:40Z',
      controlledTime: '2026-09-28T15:32:00Z',
      clearedTime: '2026-09-28T17:45:00Z',
      propertyUse: '891 - Warehouse / General Storage',
      detectorPresence: 'ALERTED',
      causeOfIgnition: 'Electrical failure in heavy equipment charger',
      estimatedLossDollars: 450000,
      apparatusAssigned: ['Engine 7', 'Engine 12', 'Truck 2', 'Truck 5', 'Squad 1', 'Battalion 2'],
      civilianInjuries: 0,
      firefighterInjuries: 1
    }
  },
  {
    id: '2026-EMS-04180',
    cadCallId: 'CAD-26-44933',
    agency: 'EMS',
    title: 'Acute STEMI & Cardiogenic Shock / Code STEMI Activated',
    incidentType: 'CARDIAC COMPLAINT (NEMSIS I21.0)',
    codeNibrsOrClass: 'I21.0 - ST Elevation Myocardial Infarction',
    status: 'APPROVED',
    occurredFrom: '2026-09-28T23:05:00Z',
    occurredTo: '2026-09-28T23:58:00Z',
    reportedDate: '2026-09-28T23:05:10Z',
    locationAddress: '741 Sunrise Boulevard, Apt 14',
    zoneBeat: 'EMS Zone 3 / Medic 9',
    reportingOfficerName: 'Paramedic Sarah Jenkins, LP',
    reportingOfficerBadge: 'EMS-302',
    assignedUnit: 'Medic 9',
    supervisorName: 'EMS Field Supervisor Kyle Vance',
    supervisorBadge: 'EMS-04',
    supervisorApprovalDate: '2026-09-29T01:10:00Z',
    narrativeText: `Medic 9 dispatched Priority 1 (Delta) for 62yo male experiencing severe substernal crushing chest pain radiating to left jaw and diaphoresis, onset 45 minutes prior to 911 call.

On patient contact at 23:11 hours, patient found seated upright, pale, diaphoretic, marked respiratory distress. Initial 12-Lead ECG acquired at 23:14 hours revealed 4mm ST segment elevation in leads V2-V5 with reciprocal ST depressions in II, III, aVF. Diagnosis: Acute Anterior STEMI.

Immediate interventions: High-flow O2 via NRB mask, Aspirin 324mg PO chewable administered, IV established (18G right antecubital), Nitroglycerin 0.4mg SL deferred due to borderline hypotension (BP 88/54). Code STEMI transmission electronically relayed to Memorial Regional Hospital Cath Lab at 23:18 hours. En route, normal saline 500mL IV bolus infused with blood pressure improving to 102/68. Patient transferred directly to Cath Lab Table 1 at Memorial Hospital with door-to-balloon readiness. Care transferred to Dr. Henderson, Interventional Cardiology.`,
    persons: [
      {
        id: 'P-301',
        role: 'PATIENT',
        fullName: 'Robert Sterling',
        dob: '1964-08-14',
        ssnMasked: '***-**-7712',
        phone: '(555) 749-2104',
        address: '741 Sunrise Boulevard, Apt 14',
        cautionFlag: 'DNR NOT Present / Full Code'
      },
      {
        id: 'P-302',
        role: 'REPORTING_PARTY',
        fullName: 'Martha Sterling',
        dob: '1966-02-18',
        ssnMasked: '***-**-8120',
        phone: '(555) 749-2104',
        address: '741 Sunrise Boulevard, Apt 14',
        cautionFlag: 'Spouse / Next of Kin'
      }
    ],
    vehicles: [],
    linkedEvidenceIds: [],
    emsData: {
      nemsisCode: 'I21.0 - ST Elevation Myocardial Infarction',
      chiefComplaint: 'Crushing 10/10 substernal chest pain radiating to jaw with diaphoresis',
      initialAcuity: 'CRITICAL_RED',
      vitals: [
        {
          id: 'V-1',
          timestamp: '23:12',
          bpSystolic: 88,
          bpDiastolic: 54,
          pulseRate: 114,
          respiratoryRate: 24,
          spo2Percent: 91,
          gcsTotal: 15,
          bloodGlucose: 138
        },
        {
          id: 'V-2',
          timestamp: '23:25',
          bpSystolic: 102,
          bpDiastolic: 68,
          pulseRate: 98,
          respiratoryRate: 18,
          spo2Percent: 98,
          gcsTotal: 15,
          bloodGlucose: 136
        }
      ],
      medicationsAdministered: [
        {
          time: '23:15',
          drug: 'Aspirin (Chewable)',
          dosage: '324 mg',
          route: 'Oral / Chewed',
          giverBadge: 'EMS-302'
        },
        {
          time: '23:20',
          drug: 'Normal Saline 0.9%',
          dosage: '500 mL bolus',
          route: 'IV Infusion (18G)',
          giverBadge: 'EMS-302'
        }
      ],
      interventions: ['12-Lead ECG (STEMI Alert)', '18G Peripheral IV line', 'High Flow Oxygen (15L/min NRB)', 'Telemedicine ECG Transmission to Cath Lab'],
      transportHospital: 'Memorial Regional Level 1 Cardiac Center',
      triageCategory: 'Red / Immediate STEMI',
      dnrVerified: false
    }
  },
  {
    id: '2026-PD-08955',
    cadCallId: 'CAD-26-44941',
    agency: 'POLICE',
    title: 'Residential Burglary in Progress - Forced Entry',
    incidentType: 'RESIDENTIAL BURGLARY (NIBRS 220)',
    codeNibrsOrClass: '220 - Burglary / Breaking & Entering',
    status: 'SUPERVISOR_REVIEW',
    occurredFrom: '2026-09-29T03:15:00Z',
    occurredTo: '2026-09-29T03:40:00Z',
    reportedDate: '2026-09-29T03:18:00Z',
    locationAddress: '2410 Westover Terrace',
    zoneBeat: 'Sector 2 / Beat 21',
    reportingOfficerName: 'Officer Daniel Choi',
    reportingOfficerBadge: 'PD-5591',
    assignedUnit: 'Unit 2-Baker-4',
    narrativeText: `On 09/29/2026 at 03:18 hrs, homeowner reported seeing two unknown subjects attempting to force open rear sliding patio door. Officers arrived at 03:22 hrs and set perimeter.

Subjects observed fleeing into greenbelt. Foot pursuit ensued; one subject, juvenile male (16yo, DOB: 09/14/2010), was apprehended. Juvenile was carrying a pry bar tool and heavy duty flashlight. Second subject escaped on an unregistered motor scooter. Suspect was turned over to Juvenile Intake Hall under citation #J-88192. Pry bar impounded as physical evidence EV-2026-8955-01. Report forwarded for supervisory sign-off and detective assignment.`,
    persons: [
      {
        id: 'P-401',
        role: 'VICTIM',
        fullName: 'Evelyn St. Claire',
        dob: '1974-12-05',
        ssnMasked: '***-**-9014',
        phone: '(555) 391-4402',
        address: '2410 Westover Terrace'
      },
      {
        id: 'P-402',
        role: 'SUSPECT',
        fullName: 'Tyler J. Vance',
        dob: '2010-09-14',
        ssnMasked: '***-**-2940',
        phone: '(555) 441-2918',
        address: '918 Crestview Way',
        isJuvenile: true,
        cautionFlag: 'JUVENILE / Statutory Sealing Required'
      }
    ],
    vehicles: [],
    linkedEvidenceIds: ['EV-2026-8955-01'],
    confidentialFlag: false
  }
];

export const INITIAL_CAD_CALLS: CADCallRecord[] = [
  {
    callId: 'CAD-26-44950',
    agency: 'FIRE',
    priority: 1,
    callType: 'MVA WITH ENTRAPMENT / PIN-IN',
    cfsCode: '322 - Motor Vehicle Crash with Extrication',
    location: 'State Route 101 at Mile Marker 14.2 Southbound',
    crossStreet: 'Skyline Overpass',
    sectorZone: 'Zone 1 / Hwy Sector',
    callerName: 'Caltrans Highway Patrol Dispatch',
    callerPhone: '(555) 767-1111',
    createdTime: '2026-09-29T07:12:00Z',
    status: 'ON_SCENE',
    units: [
      { unitId: 'Engine 4', agency: 'FIRE', dispatchedTime: '07:12:30', enRouteTime: '07:13:45', onSceneTime: '07:19:10', status: 'ON_SCENE' },
      { unitId: 'Truck 1 (Heavy Rescue)', agency: 'FIRE', dispatchedTime: '07:12:30', enRouteTime: '07:14:02', onSceneTime: '07:20:05', status: 'ON_SCENE' },
      { unitId: 'Medic 3', agency: 'EMS', dispatchedTime: '07:12:30', enRouteTime: '07:13:10', onSceneTime: '07:18:50', status: 'ON_SCENE' },
      { unitId: 'CHP Unit 84', agency: 'POLICE', dispatchedTime: '07:13:00', enRouteTime: '07:13:20', onSceneTime: '07:17:30', status: 'ON_SCENE' }
    ],
    notes: [
      { timestamp: '07:12:05', dispatcherId: 'DISP-82', noteText: 'Multiple 911 calls reporting 2-vehicle high-speed collision, sedan rolled on driver side with female driver pinned.' },
      { timestamp: '07:14:10', dispatcherId: 'DISP-82', noteText: 'Engine 4 reports smoke visible from vehicle engine compartment; dry chemical extinguisher deployed.' },
      { timestamp: '07:21:40', dispatcherId: 'DISP-82', noteText: 'Truck 1 initiating hydraulic spreader and shear cut on B-pillar. Medic 3 staging patient stabilization.' }
    ]
  },
  {
    callId: 'CAD-26-44952',
    agency: 'POLICE',
    priority: 2,
    callType: 'DOMESTIC DISTURBANCE / VERBAL TO PHYSICAL',
    cfsCode: '415 - Disturbance / Peace',
    location: '685 Willowbend Drive, Apt 4B',
    crossStreet: 'Willowbend & 7th Avenue',
    sectorZone: 'Sector 3 / Beat 31',
    callerName: 'Anonymous Neighbor',
    callerPhone: '(555) 601-9244',
    createdTime: '2026-09-29T07:25:00Z',
    status: 'CLEARED_PENDING_RMS',
    units: [
      { unitId: 'Unit 3-King-1', agency: 'POLICE', dispatchedTime: '07:25:40', enRouteTime: '07:26:10', onSceneTime: '07:31:00', clearedTime: '07:55:00', status: 'CLEARED' },
      { unitId: 'Unit 3-King-4', agency: 'POLICE', dispatchedTime: '07:25:40', enRouteTime: '07:26:15', onSceneTime: '07:32:00', clearedTime: '07:55:00', status: 'CLEARED' }
    ],
    notes: [
      { timestamp: '07:25:12', dispatcherId: 'DISP-14', noteText: 'Caller hears screaming and items being thrown against wall in Apt 4B.' },
      { timestamp: '07:34:00', dispatcherId: 'DISP-14', noteText: 'Unit 3-King-1 made contact with parties. Primary aggressor separated. No medical needed. Generating RMS incident.' }
    ]
  },
  {
    callId: 'CAD-26-44955',
    agency: 'EMS',
    priority: 1,
    callType: 'RESPIRATORY ARREST / ANAPHYLAXIS',
    cfsCode: 'E-02 - Severe Allergic Reaction',
    location: 'Central High School Cafeteria, 1200 Academic Way',
    sectorZone: 'EMS Sector 1 / Medic 6',
    callerName: 'School Nurse Beverly Adams, RN',
    callerPhone: '(555) 432-8000',
    createdTime: '2026-09-29T07:42:00Z',
    status: 'EN_ROUTE',
    units: [
      { unitId: 'Medic 6', agency: 'EMS', dispatchedTime: '07:42:30', enRouteTime: '07:43:15', status: 'EN_ROUTE' },
      { unitId: 'Engine 1 (First Responder)', agency: 'FIRE', dispatchedTime: '07:42:30', enRouteTime: '07:43:00', status: 'EN_ROUTE' }
    ],
    notes: [
      { timestamp: '07:42:20', dispatcherId: 'DISP-33', noteText: '15yo male student peanut ingestion, severe stridor, facial swelling, EpiPen 0.3mg administered by nurse with minimal relief.' },
      { timestamp: '07:44:00', dispatcherId: 'DISP-33', noteText: 'Medic 6 ETA 3 minutes, preparing IM Epinephrine 1:1,000 redose and nebulized Albuterol.' }
    ]
  }
];

export const INITIAL_EVIDENCE: EvidenceItem[] = [
  {
    trackingBarcode: 'EV-2026-8942-01',
    incidentId: '2026-PD-08942',
    category: 'WEAPON_FIREARM',
    description: 'Glock 19 Gen 5 9mm Luger handgun, black matte finish, Serial # BWF-9024, equipped with factory 15-round magazine containing 14 live 9mm hollow point rounds.',
    storageLockerLocation: 'Firearms Vault 1 / Rack 4 / Bin 12',
    dateCollected: '2026-09-28T22:05:00Z',
    collectedByOfficer: 'Marcus Vance',
    collectedByBadge: 'PD-4819',
    currentCustodian: 'Property Officer D. Alvarez (Badge #PD-092)',
    status: 'IN_VAULT',
    sha256Hash: '4a6f7b98c3e1028741da928e47bf0c2e3914a82701df92e541b9201948fc2019',
    notes: 'Recovered underneath commercial dumpster at 1380 N Meridian Blvd. Latent fingerprints lifted from slide before secure packaging.',
    chainOfCustody: [
      {
        id: 'CH-1',
        timestamp: '2026-09-28T22:05:00Z',
        action: 'RECOVERED_AT_SCENE',
        releasedByBadge: 'SCENE',
        releasedByName: 'Scene Location',
        receivedByBadge: 'PD-4819',
        receivedByName: 'Ofc. Marcus Vance',
        agencyDivision: 'Patrol Division',
        purposeReason: 'Evidence recovery and field packaging in tamper-evident rifle/handgun box',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-VER-4819-A'
      },
      {
        id: 'CH-2',
        timestamp: '2026-09-28T23:30:00Z',
        action: 'INTAKE_TO_LOCKER',
        releasedByBadge: 'PD-4819',
        releasedByName: 'Ofc. Marcus Vance',
        receivedByBadge: 'PD-092',
        receivedByName: 'Property Officer D. Alvarez',
        agencyDivision: 'Property & Evidence Bureau',
        purposeReason: 'Secure intake into main firearms vault, barcode EV-2026-8942-01 affixed',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-VER-092-B'
      }
    ]
  },
  {
    trackingBarcode: 'EV-2026-8942-02',
    incidentId: '2026-PD-08942',
    category: 'DIGITAL_BWC_VIDEO',
    description: 'Axon Body 3 Video Recording - Officer Vance (Badge PD-4819) - Full shift recording segment covering response, suspect pursuit, and weapon discovery.',
    storageLockerLocation: 'Digital Evidence Vault / Cloud Storage Tier 1 (GovCloud CJIS)',
    dateCollected: '2026-09-28T23:15:00Z',
    collectedByOfficer: 'Marcus Vance',
    collectedByBadge: 'PD-4819',
    currentCustodian: 'Digital Evidence System (Automated CJIS Server)',
    status: 'IN_VAULT',
    sha256Hash: '9e107d9d372bb6826bd81d3542a419d6da8b991ef2364177265a0c0a964bf582',
    notes: 'Raw uncompressed MP4 with synchronized GPS coordinates, audio tracks, and activation metadata.',
    chainOfCustody: [
      {
        id: 'CH-3',
        timestamp: '2026-09-28T23:15:00Z',
        action: 'INTAKE_TO_LOCKER',
        releasedByBadge: 'PD-4819',
        releasedByName: 'Ofc. Marcus Vance',
        receivedByBadge: 'SYS-RMS',
        receivedByName: 'Automated CJIS Vault Ingestion',
        agencyDivision: 'Digital Forensics',
        purposeReason: 'Dock upload from Axon 8-bay dock station with tamper cryptographic hash seal',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-DOCK-HASH-819'
      }
    ],
    digitalAssetMeta: {
      filename: 'BWC_04_VANCE_20260928_214102.mp4',
      fileSizeMb: 1480,
      durationSeconds: 2740,
      mediaType: 'VIDEO'
    }
  },
  {
    trackingBarcode: 'EV-2026-8942-03',
    incidentId: '2026-PD-08942',
    category: 'CURRENCY',
    description: 'US Currency totaling $740.00 in mixed denominations ($20s, $10s, $5s, $1s) recovered from suspect right jacket pocket.',
    storageLockerLocation: 'Currency Safe / Shelf 2 / Envelope #194',
    dateCollected: '2026-09-28T22:10:00Z',
    collectedByOfficer: 'Marcus Vance',
    collectedByBadge: 'PD-4819',
    currentCustodian: 'Property Officer D. Alvarez',
    status: 'IN_VAULT',
    sha256Hash: '38a410b9ef182a4d9401829e90218fbd82194a091823901bfa829104820194bc',
    chainOfCustody: [
      {
        id: 'CH-4',
        timestamp: '2026-09-28T22:10:00Z',
        action: 'RECOVERED_AT_SCENE',
        releasedByBadge: 'SCENE',
        releasedByName: 'Suspect Search',
        receivedByBadge: 'PD-4819',
        receivedByName: 'Ofc. Marcus Vance',
        agencyDivision: 'Patrol Division',
        purposeReason: 'Suspect search incident to arrest',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-4819-C'
      },
      {
        id: 'CH-5',
        timestamp: '2026-09-28T23:35:00Z',
        action: 'INTAKE_TO_LOCKER',
        releasedByBadge: 'PD-4819',
        releasedByName: 'Ofc. Marcus Vance',
        receivedByBadge: 'PD-092',
        receivedByName: 'Property Officer D. Alvarez',
        agencyDivision: 'Property & Evidence Bureau',
        purposeReason: 'Dual count verified by Sgt. Rodriguez ($740.00), sealed in tamper bag #89104',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-DUAL-COUNT-740'
      }
    ]
  },
  {
    trackingBarcode: 'EV-2026-FD-01429-A',
    incidentId: '2026-FD-01429',
    category: 'FORENSIC' as any,
    description: 'Cut section of 480V 3-phase industrial power feed wiring showing arcing pitting and charred industrial breaker switch from lithium forklift charger.',
    storageLockerLocation: 'Fire Arson Investigation Locker #3',
    dateCollected: '2026-09-28T16:20:00Z',
    collectedByOfficer: 'Capt. Luis Ruiz (Arson / Fire Origin)',
    collectedByBadge: 'FD-INV-12',
    currentCustodian: 'Capt. Luis Ruiz',
    status: 'IN_VAULT',
    sha256Hash: '7c8914b102948a0f812948bc019248fa91820491820bc019248102948190248a',
    chainOfCustody: [
      {
        id: 'CH-6',
        timestamp: '2026-09-28T16:20:00Z',
        action: 'RECOVERED_AT_SCENE',
        releasedByBadge: 'SCENE',
        releasedByName: 'Warehouse Floor Sector B/C',
        receivedByBadge: 'FD-INV-12',
        receivedByName: 'Capt. Luis Ruiz',
        agencyDivision: 'Fire Investigation Unit',
        purposeReason: 'Physical arson/origin evidence collected for electrical engineering laboratory examination',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-FD-RUIZ-01'
      }
    ]
  },
  {
    trackingBarcode: 'EV-2026-8955-01',
    incidentId: '2026-PD-08955',
    category: 'PROPERTY_IMPOUND',
    description: '18-inch hardened steel crowbar / pry tool with red rubber grip, containing blue paint transfer residue consistent with damaged patio door frame.',
    storageLockerLocation: 'Property Room / Bin 82',
    dateCollected: '2026-09-29T03:30:00Z',
    collectedByOfficer: 'Daniel Choi',
    collectedByBadge: 'PD-5591',
    currentCustodian: 'Property Officer D. Alvarez',
    status: 'IN_VAULT',
    sha256Hash: '1a90284b8102948190284102948bc10294801924810294810294810294810294',
    chainOfCustody: [
      {
        id: 'CH-7',
        timestamp: '2026-09-29T03:30:00Z',
        action: 'RECOVERED_AT_SCENE',
        releasedByBadge: 'SCENE',
        releasedByName: 'Scene of Burglary',
        receivedByBadge: 'PD-5591',
        receivedByName: 'Ofc. Daniel Choi',
        agencyDivision: 'Patrol Division',
        purposeReason: 'Burglary tool recovered from juvenile suspect backpack',
        tamperSealIntact: true,
        signatureVerificationId: 'SIG-CHOI-5591'
      }
    ]
  }
];

export const INITIAL_FOIA_REQUESTS: FOIARequestRecord[] = [
  {
    requestId: 'FOIA-2026-0419',
    requestorName: 'Rachel Greenburg',
    requestorOrganization: 'Metropolitan Daily Herald / Investigative Desk',
    requestorEmail: 'rgreenburg@dailyherald.org',
    requestDate: '2026-09-28T16:00:00Z',
    statutoryDueDate: '2026-10-12T17:00:00Z', // 10 business day statutory rule
    targetIncidentId: '2026-PD-08942',
    recordTypeRequested: 'FULL_POLICE_REPORT',
    status: 'IN_REDACTION',
    notes: 'Requesting full incident report, 911 dispatch audio log, and officer body camera metadata for armed robbery at 1420 N Meridian.',
    redactions: [
      {
        id: 'RED-1',
        startIndex: 218,
        endIndex: 260,
        originalText: 'Dave Higgins, DOB: 04/12/1988',
        exemptionCode: 'PRIVACY_552_B7C',
        exemptionLabel: '5 U.S.C. § 552(b)(7)(C) - Victim Privacy',
        redactedReplacementText: '[REDACTED: 5 U.S.C. § 552(b)(7)(C) - VICTIM IDENTITY]'
      },
      {
        id: 'RED-2',
        startIndex: 580,
        endIndex: 615,
        originalText: 'DOB: 06/22/1997, SSN: XXX-XX-4819',
        exemptionCode: 'CJIS_PII_SSN',
        exemptionLabel: 'CJIS PII / Social Security & DOB',
        redactedReplacementText: '[REDACTED: CJIS/PII STATUTORY EXEMPTION]'
      }
    ]
  },
  {
    requestId: 'FOIA-2026-0412',
    requestorName: 'Arthur Vance, Esq.',
    requestorOrganization: 'Vance & Sterling Legal Associates',
    requestorEmail: 'avance@vancelegal.com',
    requestDate: '2026-09-29T04:10:00Z',
    statutoryDueDate: '2026-10-13T17:00:00Z',
    targetIncidentId: '2026-PD-08955',
    recordTypeRequested: 'FULL_POLICE_REPORT',
    status: 'SUBMITTED',
    notes: 'Submitting formal request for reports regarding 2410 Westover Terrace incident. Client requesting all officer narratives.',
    redactions: []
  },
  {
    requestId: 'FOIA-2026-0398',
    requestorName: 'Safety Watchdog Coalition',
    requestorOrganization: 'Non-Profit Civic Transparency Project',
    requestorEmail: 'records@safetywatchdog.org',
    requestDate: '2026-09-25T11:00:00Z',
    statutoryDueDate: '2026-10-09T17:00:00Z',
    targetIncidentId: '2026-FD-01429',
    recordTypeRequested: 'FIRE_INVESTIGATION',
    status: 'RELEASED_SANITIZED',
    certificationSealNumber: 'SEAL-2026-DISCLOSE-8910',
    releasedDate: '2026-09-28T20:00:00Z',
    complianceOfficerBadge: 'RECORDS-04',
    notes: 'NFIRS report released with proprietary warehouse blueprints and trade secret chemicals sanitized under exemption (b)(4).',
    redactions: [
      {
        id: 'RED-3',
        startIndex: 180,
        endIndex: 215,
        originalText: 'Carlos Mendoza, DOB: 1979-11-03',
        exemptionCode: 'PRIVACY_552_B7C',
        exemptionLabel: '5 U.S.C. § 552(b)(7)(C) - Privacy',
        redactedReplacementText: '[REDACTED: 5 U.S.C. § 552(b)(7)(C)]'
      }
    ]
  }
];

export const INITIAL_AUDIT_LOGS: CJISAuditLogEntry[] = [
  {
    id: 'AUD-991',
    timestamp: '2026-09-29T07:44:12Z',
    officerBadge: 'PD-4819',
    officerName: 'Marcus Vance',
    terminalIp: '10.240.12.84 (MDT Mobile 4A-12)',
    agencyDivision: 'Patrol Division',
    action: 'RECORD_VIEW',
    recordIdentifier: '2026-PD-08942',
    details: 'Viewed criminal incident master record and linked evidence locker items',
    cjisClearanceLevel: 'LEVEL_2_OFFICER'
  },
  {
    id: 'AUD-990',
    timestamp: '2026-09-29T07:12:00Z',
    officerBadge: 'DISP-82',
    officerName: 'Dispatcher H. Kline',
    terminalIp: '10.240.1.12 (PSAP Console 4)',
    agencyDivision: 'Communications / 911 Dispatch',
    action: 'CAD_TO_RMS_CONVERSION',
    recordIdentifier: 'CAD-26-44950',
    details: 'CAD call initiated for 101 Freeway pin-in rescue with automatic unit telematics sync',
    cjisClearanceLevel: 'LEVEL_1_OPERATOR'
  },
  {
    id: 'AUD-989',
    timestamp: '2026-09-29T03:42:00Z',
    officerBadge: 'PD-5591',
    officerName: 'Daniel Choi',
    terminalIp: '10.240.8.22 (Station Terminal B)',
    agencyDivision: 'Patrol Division',
    action: 'RECORD_CREATE',
    recordIdentifier: '2026-PD-08955',
    details: 'Generated new residential burglary incident report with linked juvenile suspect record',
    cjisClearanceLevel: 'LEVEL_2_OFFICER'
  },
  {
    id: 'AUD-988',
    timestamp: '2026-09-29T02:15:00Z',
    officerBadge: 'PD-1102',
    officerName: 'Sgt. Elena Rodriguez',
    terminalIp: '10.240.4.10 (Supervisor Desk)',
    agencyDivision: 'Patrol Supervision',
    action: 'SUPERVISOR_APPROVAL',
    recordIdentifier: '2026-PD-08942',
    details: 'Electronic supervisory review approved and signed; CJIS checksum stamped',
    cjisClearanceLevel: 'LEVEL_3_SUPERVISOR'
  },
  {
    id: 'AUD-987',
    timestamp: '2026-09-28T23:35:00Z',
    officerBadge: 'PD-092',
    officerName: 'D. Alvarez',
    terminalIp: '10.240.19.4 (Evidence Vault Workstation)',
    agencyDivision: 'Property & Evidence',
    action: 'EVIDENCE_CUSTODY_TRANSFER',
    recordIdentifier: 'EV-2026-8942-01',
    details: 'Vault intake chain of custody recorded with SHA-256 seal verification',
    cjisClearanceLevel: 'LEVEL_2_OFFICER'
  }
];

export const INITIAL_MASTER_PERSONS: MasterPersonRecord[] = [
  {
    id: 'MP-8910',
    fullName: 'James Richard Wallace',
    dob: '1997-06-22',
    ssnMasked: '***-**-4819',
    gender: 'Male',
    race: 'White',
    address: '1120 South Oak Lane',
    phone: '(555) 819-0021',
    aliases: ['"Jimmy Quick"', 'James R. Miller'],
    cautionFlags: ['Violent Offense Record', 'Known Weapon Carrier', 'Escape Risk / Flight'],
    linkedIncidents: [
      { incidentId: '2026-PD-08942', role: 'SUSPECT', date: '2026-09-28', agency: 'POLICE' },
      { incidentId: '2024-PD-04192', role: 'SUSPECT', date: '2024-11-12', agency: 'POLICE' }
    ]
  },
  {
    id: 'MP-8911',
    fullName: 'Robert Sterling',
    dob: '1964-08-14',
    ssnMasked: '***-**-7712',
    gender: 'Male',
    race: 'White',
    address: '741 Sunrise Boulevard, Apt 14',
    phone: '(555) 749-2104',
    aliases: [],
    cautionFlags: ['Cardiac History / Prior Stent', 'Penicillin Allergy'],
    linkedIncidents: [
      { incidentId: '2026-EMS-04180', role: 'PATIENT', date: '2026-09-28', agency: 'EMS' }
    ]
  },
  {
    id: 'MP-8912',
    fullName: 'Tyler J. Vance',
    dob: '2010-09-14',
    ssnMasked: '***-**-2940',
    gender: 'Male',
    race: 'Hispanic',
    address: '918 Crestview Way',
    phone: '(555) 441-2918',
    aliases: [],
    cautionFlags: ['JUVENILE STATUTORY PRIVACY ENFORCED'],
    linkedIncidents: [
      { incidentId: '2026-PD-08955', role: 'SUSPECT', date: '2026-09-29', agency: 'POLICE' }
    ]
  }
];

export const INITIAL_MASTER_VEHICLES: MasterVehicleRecord[] = [
  {
    vin: '1HGCR2F83HA029184',
    plate: '7XYZ890',
    state: 'CA',
    make: 'Honda',
    model: 'Accord',
    year: 2017,
    color: 'Silver',
    registeredOwner: 'Wallace, James R.',
    isStolen: false,
    linkedIncidents: ['2026-PD-08942']
  },
  {
    vin: '2C3CDXBG8KH582910',
    plate: '8KLP491',
    state: 'CA',
    make: 'Dodge',
    model: 'Charger',
    year: 2019,
    color: 'Black',
    registeredOwner: 'Unknown / Stolen Report Pending',
    isStolen: true,
    linkedIncidents: ['CAD-26-44950']
  }
];
