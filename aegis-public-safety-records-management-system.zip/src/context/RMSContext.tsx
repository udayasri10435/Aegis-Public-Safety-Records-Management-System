import React, { createContext, useContext, useState, useEffect } from 'react';
import { IncidentReport, AgencyType } from '../types/rms';
import { CADCallRecord } from '../types/cad';
import { EvidenceItem, CustodyAction, CustodyEvent } from '../types/evidence';
import { FOIARequestRecord, RedactionMark } from '../types/foia';
import { CJISAuditLogEntry, MasterPersonRecord, MasterVehicleRecord, AuditActionType } from '../types/audit';
import {
  INITIAL_INCIDENTS,
  INITIAL_CAD_CALLS,
  INITIAL_EVIDENCE,
  INITIAL_FOIA_REQUESTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_MASTER_PERSONS,
  INITIAL_MASTER_VEHICLES
} from '../data/initialData';

export type NavigationTab = 'incidents' | 'cad' | 'evidence' | 'foia' | 'master_indices' | 'audit_log';

interface NCICQueryResult {
  queryType: 'WARRANT' | 'STOLEN_VEHICLE' | 'DRIVER_LICENSE';
  searchTerm: string;
  status: 'HIT_FOUND' | 'NO_RECORD' | 'CAUTION_WARRANT';
  details: string;
  agencyOrigin: string;
  timestamp: string;
}

interface RMSContextType {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  activeAgencyFilter: 'ALL' | AgencyType;
  setActiveAgencyFilter: (agency: 'ALL' | AgencyType) => void;
  incidents: IncidentReport[];
  cadCalls: CADCallRecord[];
  evidence: EvidenceItem[];
  foiaRequests: FOIARequestRecord[];
  auditLogs: CJISAuditLogEntry[];
  masterPersons: MasterPersonRecord[];
  masterVehicles: MasterVehicleRecord[];
  
  // Incident methods
  createIncident: (incident: IncidentReport) => void;
  updateIncident: (id: string, updates: Partial<IncidentReport>) => void;
  approveIncident: (id: string, supervisorName: string, supervisorBadge: string) => void;
  
  // CAD methods
  convertCadToRms: (cadCallId: string) => IncidentReport;
  updateCadCallStatus: (callId: string, status: any) => void;
  
  // Evidence methods
  addEvidence: (item: EvidenceItem) => void;
  transferEvidenceCustody: (
    barcode: string,
    event: {
      action: CustodyAction;
      releasedByBadge: string;
      releasedByName: string;
      receivedByBadge: string;
      receivedByName: string;
      agencyDivision: string;
      purposeReason: string;
      tamperSealIntact: boolean;
    }
  ) => void;
  
  // FOIA methods
  createFOIARequest: (request: FOIARequestRecord) => void;
  updateFOIARedactions: (requestId: string, redactions: RedactionMark[]) => void;
  releaseFOIAPackage: (requestId: string, certSeal: string, officerBadge: string) => void;
  
  // CJIS Query & Audit
  logAudit: (action: AuditActionType, recordId: string, details: string) => void;
  queryNCIC: (type: 'WARRANT' | 'STOLEN_VEHICLE' | 'DRIVER_LICENSE', term: string) => NCICQueryResult;
  resetAllData: () => void;
}

const RMSContext = createContext<RMSContextType | null>(null);

const STORAGE_KEYS = {
  INCIDENTS: 'aegis_rms_incidents_v1',
  CAD: 'aegis_rms_cad_v1',
  EVIDENCE: 'aegis_rms_evidence_v1',
  FOIA: 'aegis_rms_foia_v1',
  AUDIT: 'aegis_rms_audit_v1',
  PERSONS: 'aegis_rms_persons_v1',
  VEHICLES: 'aegis_rms_vehicles_v1'
};

export const RMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavigationTab>('incidents');
  const [activeAgencyFilter, setActiveAgencyFilter] = useState<'ALL' | AgencyType>('ALL');

  // Load state with fallback to initial fixtures
  const [incidents, setIncidents] = useState<IncidentReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INCIDENTS);
      return saved ? JSON.parse(saved) : INITIAL_INCIDENTS;
    } catch {
      return INITIAL_INCIDENTS;
    }
  });

  const [cadCalls, setCadCalls] = useState<CADCallRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CAD);
      return saved ? JSON.parse(saved) : INITIAL_CAD_CALLS;
    } catch {
      return INITIAL_CAD_CALLS;
    }
  });

  const [evidence, setEvidence] = useState<EvidenceItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EVIDENCE);
      return saved ? JSON.parse(saved) : INITIAL_EVIDENCE;
    } catch {
      return INITIAL_EVIDENCE;
    }
  });

  const [foiaRequests, setFoiaRequests] = useState<FOIARequestRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FOIA);
      return saved ? JSON.parse(saved) : INITIAL_FOIA_REQUESTS;
    } catch {
      return INITIAL_FOIA_REQUESTS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<CJISAuditLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.AUDIT);
      return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  const [masterPersons, setMasterPersons] = useState<MasterPersonRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PERSONS);
      return saved ? JSON.parse(saved) : INITIAL_MASTER_PERSONS;
    } catch {
      return INITIAL_MASTER_PERSONS;
    }
  });

  const [masterVehicles, setMasterVehicles] = useState<MasterVehicleRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.VEHICLES);
      return saved ? JSON.parse(saved) : INITIAL_MASTER_VEHICLES;
    } catch {
      return INITIAL_MASTER_VEHICLES;
    }
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INCIDENTS, JSON.stringify(incidents));
  }, [incidents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CAD, JSON.stringify(cadCalls));
  }, [cadCalls]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EVIDENCE, JSON.stringify(evidence));
  }, [evidence]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FOIA, JSON.stringify(foiaRequests));
  }, [foiaRequests]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(auditLogs));
  }, [auditLogs]);

  const logAudit = (action: AuditActionType, recordIdentifier: string, details: string) => {
    const newEntry: CJISAuditLogEntry = {
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      officerBadge: 'PD-4819',
      officerName: 'Ofc. Marcus Vance (Active User)',
      terminalIp: '10.240.12.84 (Workstation Terminal #1)',
      agencyDivision: 'Patrol / Public Safety Records',
      action,
      recordIdentifier,
      details,
      cjisClearanceLevel: 'LEVEL_2_OFFICER'
    };
    setAuditLogs(prev => [newEntry, ...prev]);
  };

  const createIncident = (incident: IncidentReport) => {
    setIncidents(prev => [incident, ...prev]);
    logAudit('RECORD_CREATE', incident.id, `Created new ${incident.agency} incident report: ${incident.title}`);
  };

  const updateIncident = (id: string, updates: Partial<IncidentReport>) => {
    setIncidents(prev =>
      prev.map(item => (item.id === id ? { ...item, ...updates } : item))
    );
    logAudit('RECORD_EDIT', id, `Updated incident details and narratives for ${id}`);
  };

  const approveIncident = (id: string, supervisorName: string, supervisorBadge: string) => {
    setIncidents(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              status: 'APPROVED',
              supervisorName,
              supervisorBadge,
              supervisorApprovalDate: new Date().toISOString()
            }
          : item
      )
    );
    logAudit('SUPERVISOR_APPROVAL', id, `Supervisory sign-off executed by ${supervisorName} (${supervisorBadge})`);
  };

  const convertCadToRms = (cadCallId: string): IncidentReport => {
    const cadCall = cadCalls.find(c => c.callId === cadCallId);
    if (!cadCall) {
      throw new Error(`CAD Call ${cadCallId} not found`);
    }

    const yearPrefix = new Date().getFullYear();
    const agencyCode = cadCall.agency === 'POLICE' ? 'PD' : cadCall.agency === 'FIRE' ? 'FD' : 'EMS';
    const randNum = Math.floor(1000 + Math.random() * 9000);
    const newIncidentId = `${yearPrefix}-${agencyCode}-${randNum}`;

    // Map call notes into initial narrative
    const notesSummary = cadCall.notes
      .map(n => `[CAD ${n.timestamp} by ${n.dispatcherId}]: ${n.noteText}`)
      .join('\n\n');

    const primaryUnit = cadCall.units[0]?.unitId || 'Unit 1';

    const newReport: IncidentReport = {
      id: newIncidentId,
      cadCallId: cadCall.callId,
      agency: cadCall.agency,
      title: `${cadCall.callType} at ${cadCall.location}`,
      incidentType: cadCall.callType,
      codeNibrsOrClass: cadCall.cfsCode,
      status: 'DRAFT',
      occurredFrom: cadCall.createdTime,
      reportedDate: new Date().toISOString(),
      locationAddress: cadCall.location,
      zoneBeat: cadCall.sectorZone,
      reportingOfficerName: 'Marcus Vance',
      reportingOfficerBadge: 'PD-4819',
      assignedUnit: primaryUnit,
      narrativeText: `CAD CALL ORIGIN: ${cadCall.callId}\nCaller: ${cadCall.callerName} (${cadCall.callerPhone})\nLocation: ${cadCall.location}\n\nCAD DISPATCH LOG:\n${notesSummary}\n\n[OFFICER SYNOPSIS TO BE COMPLETED]`,
      persons: [
        {
          id: `P-${Date.now().toString().slice(-4)}`,
          role: 'REPORTING_PARTY',
          fullName: cadCall.callerName,
          dob: '1985-01-01',
          ssnMasked: '***-**-0000',
          phone: cadCall.callerPhone,
          address: cadCall.location,
          cautionFlag: 'CAD 911 Caller'
        }
      ],
      vehicles: [],
      linkedEvidenceIds: []
    };

    if (cadCall.agency === 'FIRE') {
      newReport.fireData = {
        nfirsCode: cadCall.cfsCode,
        alarmTime: cadCall.createdTime,
        arrivalFirstUnit: cadCall.units[0]?.onSceneTime || new Date().toISOString(),
        controlledTime: '',
        clearedTime: '',
        propertyUse: 'Standard Commercial / Residential',
        detectorPresence: 'ALERTED',
        causeOfIgnition: 'Under Investigation',
        estimatedLossDollars: 0,
        apparatusAssigned: cadCall.units.map(u => u.unitId),
        civilianInjuries: 0,
        firefighterInjuries: 0
      };
    } else if (cadCall.agency === 'EMS') {
      newReport.emsData = {
        nemsisCode: cadCall.cfsCode,
        chiefComplaint: cadCall.callType,
        initialAcuity: cadCall.priority === 1 ? 'CRITICAL_RED' : 'EMERGENT_YELLOW',
        vitals: [
          {
            id: `VIT-${Date.now()}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            bpSystolic: 120,
            bpDiastolic: 80,
            pulseRate: 76,
            respiratoryRate: 16,
            spo2Percent: 98,
            gcsTotal: 15
          }
        ],
        medicationsAdministered: [],
        interventions: ['Initial Patient Assessment', 'Vitals Acquired'],
        transportHospital: 'Mercy General Hospital Emergency Dept',
        triageCategory: 'Urgent',
        dnrVerified: false
      };
    }

    setIncidents(prev => [newReport, ...prev]);

    // Mark CAD call as transferred
    setCadCalls(prev =>
      prev.map(c =>
        c.callId === cadCallId
          ? { ...c, status: 'TRANSFERRED_TO_RMS', rmsIncidentId: newIncidentId }
          : c
      )
    );

    logAudit('CAD_TO_RMS_CONVERSION', cadCallId, `Converted CAD Call ${cadCallId} to RMS Record ${newIncidentId}`);
    return newReport;
  };

  const updateCadCallStatus = (callId: string, status: any) => {
    setCadCalls(prev =>
      prev.map(c => (c.callId === callId ? { ...c, status } : c))
    );
  };

  const addEvidence = (item: EvidenceItem) => {
    setEvidence(prev => [item, ...prev]);
    // Link to incident if present
    if (item.incidentId) {
      setIncidents(prev =>
        prev.map(inc =>
          inc.id === item.incidentId && !inc.linkedEvidenceIds.includes(item.trackingBarcode)
            ? { ...inc, linkedEvidenceIds: [...inc.linkedEvidenceIds, item.trackingBarcode] }
            : inc
        )
      );
    }
    logAudit('RECORD_CREATE', item.trackingBarcode, `Evidence logged: ${item.description.slice(0, 50)}...`);
  };

  const transferEvidenceCustody = (
    barcode: string,
    eventData: {
      action: CustodyAction;
      releasedByBadge: string;
      releasedByName: string;
      receivedByBadge: string;
      receivedByName: string;
      agencyDivision: string;
      purposeReason: string;
      tamperSealIntact: boolean;
    }
  ) => {
    const newEvent: CustodyEvent = {
      id: `CH-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      ...eventData,
      signatureVerificationId: `SIG-EVID-${Math.random().toString(36).substring(2, 9).toUpperCase()}`
    };

    let newStatus: EvidenceItem['status'] = 'IN_VAULT';
    if (eventData.action === 'CHECKED_OUT_LAB') newStatus = 'OUT_AT_LAB';
    if (eventData.action === 'CHECKED_OUT_COURT') newStatus = 'IN_COURT';
    if (eventData.action === 'RELEASED_TO_OWNER') newStatus = 'RELEASED';
    if (eventData.action === 'FINAL_DISPOSITION_DESTROYED') newStatus = 'DISPOSED';

    setEvidence(prev =>
      prev.map(item =>
        item.trackingBarcode === barcode
          ? {
              ...item,
              status: newStatus,
              currentCustodian: `${eventData.receivedByName} (${eventData.receivedByBadge})`,
              chainOfCustody: [...item.chainOfCustody, newEvent]
            }
          : item
      )
    );

    logAudit(
      'EVIDENCE_CUSTODY_TRANSFER',
      barcode,
      `Custody transferred to ${eventData.receivedByName} (${eventData.action}) - Reason: ${eventData.purposeReason}`
    );
  };

  const createFOIARequest = (request: FOIARequestRecord) => {
    setFoiaRequests(prev => [request, ...prev]);
    logAudit('RECORD_CREATE', request.requestId, `Intake FOIA public record request by ${request.requestorName}`);
  };

  const updateFOIARedactions = (requestId: string, redactions: RedactionMark[]) => {
    setFoiaRequests(prev =>
      prev.map(req =>
        req.requestId === requestId
          ? { ...req, redactions, status: 'IN_REDACTION' }
          : req
      )
    );
    logAudit('FOIA_REDACTION_APPLIED', requestId, `Updated ${redactions.length} statutory redaction masks on ${requestId}`);
  };

  const releaseFOIAPackage = (requestId: string, certSeal: string, officerBadge: string) => {
    setFoiaRequests(prev =>
      prev.map(req =>
        req.requestId === requestId
          ? {
              ...req,
              status: 'RELEASED_SANITIZED',
              certificationSealNumber: certSeal,
              complianceOfficerBadge: officerBadge,
              releasedDate: new Date().toISOString()
            }
          : req
      )
    );
    logAudit('FOIA_PACKAGE_EXPORTED', requestId, `Certified public disclosure packet released with Seal #${certSeal}`);
  };

  const queryNCIC = (type: 'WARRANT' | 'STOLEN_VEHICLE' | 'DRIVER_LICENSE', term: string): NCICQueryResult => {
    const cleanTerm = term.trim().toUpperCase();
    logAudit('NCIC_CJIS_QUERY', cleanTerm, `NCIC/CJIS Inquiry [${type}] for "${cleanTerm}"`);

    if (type === 'WARRANT') {
      if (cleanTerm.includes('WALLACE') || cleanTerm.includes('JAMES')) {
        return {
          queryType: 'WARRANT',
          searchTerm: term,
          status: 'CAUTION_WARRANT',
          details: 'FELONY ARREST WARRANT #W-89210 ISSUED BY SUPERIOR COURT - ARMED ROBBERY / PROBATION VIOLATION. EXTRADITION CODE: FULL EXTRADITION 50 STATES. CAUTION: KNOWN TO CARRY CONCEALED WEAPONS.',
          agencyOrigin: 'State Dept of Justice / NCIC',
          timestamp: new Date().toISOString()
        };
      }
      return {
        queryType: 'WARRANT',
        searchTerm: term,
        status: 'NO_RECORD',
        details: 'NO ACTIVE OUTSTANDING ARREST WARRANTS OR NCIC BOLO LOCATED FOR SPECIFIED IDENTITY.',
        agencyOrigin: 'NCIC Interstate Identification Index (III)',
        timestamp: new Date().toISOString()
      };
    }

    if (type === 'STOLEN_VEHICLE') {
      if (cleanTerm.includes('8KLP491') || cleanTerm.includes('2C3CDXBG8KH582910')) {
        return {
          queryType: 'STOLEN_VEHICLE',
          searchTerm: term,
          status: 'HIT_FOUND',
          details: 'ACTIVE STOLEN VEHICLE RECORD #SV-2026-99214. 2019 DODGE CHARGER SEDAN BLACK. REPORTED STOLEN TO METRO POLICE ON 09/27/2026. HOLD VEHICLE FOR EVIDENCE / CRIME LAB PRINTS.',
          agencyOrigin: 'NCIC Stolen Vehicle File',
          timestamp: new Date().toISOString()
        };
      }
      return {
        queryType: 'STOLEN_VEHICLE',
        searchTerm: term,
        status: 'NO_RECORD',
        details: 'NO STOLEN RECORD LOCATED. VEHICLE TITLE ACTIVE / NO STOLEN FLAGS ON FILE.',
        agencyOrigin: 'State DMV / NCIC Vehicle Record',
        timestamp: new Date().toISOString()
      };
    }

    // Driver License
    return {
      queryType: 'DRIVER_LICENSE',
      searchTerm: term,
      status: 'HIT_FOUND',
      details: `STATE DMV DRIVER RECORD VALID. CLASS C COMMERCIAL VEHICLE ENDORSEMENT: NONE. MEDICAL RESTRICTION: CORRECTIVE LENSES. EXPIRATION: 2028-11-15. ZERO SUSPENSIONS.`,
      agencyOrigin: 'State DMV Driver Record Clearinghouse',
      timestamp: new Date().toISOString()
    };
  };

  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEYS.INCIDENTS);
    localStorage.removeItem(STORAGE_KEYS.CAD);
    localStorage.removeItem(STORAGE_KEYS.EVIDENCE);
    localStorage.removeItem(STORAGE_KEYS.FOIA);
    localStorage.removeItem(STORAGE_KEYS.AUDIT);
    localStorage.removeItem(STORAGE_KEYS.PERSONS);
    localStorage.removeItem(STORAGE_KEYS.VEHICLES);

    setIncidents(INITIAL_INCIDENTS);
    setCadCalls(INITIAL_CAD_CALLS);
    setEvidence(INITIAL_EVIDENCE);
    setFoiaRequests(INITIAL_FOIA_REQUESTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setMasterPersons(INITIAL_MASTER_PERSONS);
    setMasterVehicles(INITIAL_MASTER_VEHICLES);
  };

  return (
    <RMSContext.Provider
      value={{
        activeTab,
        setActiveTab,
        activeAgencyFilter,
        setActiveAgencyFilter,
        incidents,
        cadCalls,
        evidence,
        foiaRequests,
        auditLogs,
        masterPersons,
        masterVehicles,
        createIncident,
        updateIncident,
        approveIncident,
        convertCadToRms,
        updateCadCallStatus,
        addEvidence,
        transferEvidenceCustody,
        createFOIARequest,
        updateFOIARedactions,
        releaseFOIAPackage,
        logAudit,
        queryNCIC,
        resetAllData
      }}
    >
      {children}
    </RMSContext.Provider>
  );
};

export const useRMS = () => {
  const ctx = useContext(RMSContext);
  if (!ctx) {
    throw new Error('useRMS must be used within an RMSProvider');
  }
  return ctx;
};
