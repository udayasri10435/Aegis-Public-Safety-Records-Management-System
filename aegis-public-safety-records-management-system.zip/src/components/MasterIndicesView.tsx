import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { MasterPersonRecord, MasterVehicleRecord } from '../types/audit';
import {
  Users,
  Car,
  MapPin,
  Search,
  AlertTriangle,
  FileText,
  Shield,
  Phone,
  Home
} from 'lucide-react';

interface MasterIndicesViewProps {
  onSelectIncidentById: (id: string) => void;
}

export const MasterIndicesView: React.FC<MasterIndicesViewProps> = ({ onSelectIncidentById }) => {
  const { masterPersons, masterVehicles } = useRMS();

  const [activeTab, setActiveTab] = useState<'PERSONS' | 'VEHICLES' | 'LOCATIONS'>('PERSONS');
  const [searchQuery, setSearchQuery] = useState('');

  // Mock Master Locations
  const masterLocations = [
    {
      id: 'LOC-101',
      address: '1420 North Meridian Boulevard',
      zone: 'Sector 4 / Beat 42',
      hazardFlags: ['Commercial Fuel Dispenser on Premise', 'Prior Armed Robbery (2026)'],
      occupant: 'QuikStop Mart / Fuel Service',
      linkedIncidents: ['2026-PD-08942']
    },
    {
      id: 'LOC-102',
      address: '3820 Industrial Parkway',
      zone: 'Battalion 2 / Fire District 7',
      hazardFlags: ['Lithium-Ion Battery Charging Station', 'High-Piled Combustible Storage'],
      occupant: 'Apex Logistics Corp',
      linkedIncidents: ['2026-FD-01429']
    },
    {
      id: 'LOC-103',
      address: '741 Sunrise Boulevard, Apt 14',
      zone: 'EMS Zone 3',
      hazardFlags: ['Oxygen Tank in Bedroom', 'Non-Ambulatory Elderly Resident'],
      occupant: 'Robert & Martha Sterling',
      linkedIncidents: ['2026-EMS-04180']
    }
  ];

  // Filtering
  const filteredPersons = masterPersons.filter(p => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      p.fullName.toLowerCase().includes(q) ||
      p.address.toLowerCase().includes(q) ||
      p.phone.includes(q) ||
      p.aliases.some(a => a.toLowerCase().includes(q))
    );
  });

  const filteredVehicles = masterVehicles.filter(v => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      v.plate.toLowerCase().includes(q) ||
      v.vin.toLowerCase().includes(q) ||
      v.make.toLowerCase().includes(q) ||
      v.model.toLowerCase().includes(q) ||
      v.registeredOwner.toLowerCase().includes(q)
    );
  });

  const filteredLocations = masterLocations.filter(l => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      l.address.toLowerCase().includes(q) ||
      l.occupant.toLowerCase().includes(q) ||
      l.hazardFlags.some(h => h.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight">
              Master Cross-Agency Indices
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Master Name Index (MNI) · Master Vehicle Index (MVI) · Master Location Premise Index (MLI)
            </p>
          </div>
        </div>

        {/* Index Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg text-xs">
          <button
            onClick={() => setActiveTab('PERSONS')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'PERSONS'
                ? 'bg-slate-800 text-cyan-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Master Name (MNI)</span>
          </button>
          <button
            onClick={() => setActiveTab('VEHICLES')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'VEHICLES'
                ? 'bg-slate-800 text-cyan-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Car className="w-3.5 h-3.5" />
            <span>Master Vehicle (MVI)</span>
          </button>
          <button
            onClick={() => setActiveTab('LOCATIONS')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'LOCATIONS'
                ? 'bg-slate-800 text-cyan-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Premise Hazard (MLI)</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={
              activeTab === 'PERSONS'
                ? 'Search by name, alias, address, phone...'
                : activeTab === 'VEHICLES'
                ? 'Search by license plate, VIN, owner, make/model...'
                : 'Search by address, premise hazard, occupant...'
            }
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Tab 1: Master Name Index (MNI) */}
      {activeTab === 'PERSONS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPersons.map(person => (
            <div
              key={person.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 text-xs"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm">{person.fullName}</h3>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                    DOB: {person.dob} · SSN: {person.ssnMasked}
                  </div>
                </div>
                <span className="font-mono text-[10px] text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded">
                  {person.id}
                </span>
              </div>

              {/* Aliases */}
              {person.aliases.length > 0 && (
                <div className="text-slate-400">
                  <span className="font-semibold text-slate-300">Aliases:</span>{' '}
                  {person.aliases.join(', ')}
                </div>
              )}

              {/* Address & Contact */}
              <div className="space-y-1 text-slate-300">
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Home className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span className="truncate">{person.address}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                  <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span>{person.phone}</span>
                </div>
              </div>

              {/* Caution Flags */}
              {person.cautionFlags.length > 0 && (
                <div className="space-y-1 pt-1 border-t border-slate-800">
                  {person.cautionFlags.map((flag, idx) => (
                    <div
                      key={idx}
                      className="text-amber-300 font-semibold text-[11px] flex items-center gap-1"
                    >
                      <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                      <span>{flag}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Linked Incident Cases */}
              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <div className="text-[11px] font-semibold text-slate-400 uppercase">
                  Incident History ({person.linkedIncidents.length})
                </div>
                {person.linkedIncidents.map((link, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => onSelectIncidentById(link.incidentId)}
                    className="w-full text-left p-1.5 bg-slate-950 rounded hover:bg-slate-800 transition-colors flex items-center justify-between text-[11px] font-mono cursor-pointer"
                  >
                    <span className="text-cyan-400 font-semibold">{link.incidentId}</span>
                    <span className="text-slate-400 font-sans">{link.role}</span>
                    <span className="text-slate-500">{link.date}</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Master Vehicle Index (MVI) */}
      {activeTab === 'VEHICLES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVehicles.map(veh => (
            <div
              key={veh.vin}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 text-xs"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-mono text-base font-bold text-white tracking-wider">
                    {veh.plate} <span className="text-slate-500 text-xs">({veh.state})</span>
                  </div>
                  <div className="text-slate-300 font-semibold mt-0.5">
                    {veh.year} {veh.make} {veh.model} ({veh.color})
                  </div>
                </div>

                {veh.isStolen ? (
                  <span className="text-[10px] font-bold text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded border border-rose-500/30">
                    STOLEN FLAGGED
                  </span>
                ) : (
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                    ACTIVE TITLE
                  </span>
                )}
              </div>

              <div className="space-y-1 font-mono text-[11px] text-slate-400">
                <div>VIN: <span className="text-slate-200">{veh.vin}</span></div>
                <div>OWNER: <span className="text-slate-200 font-sans">{veh.registeredOwner}</span></div>
              </div>

              {/* Linked Incident */}
              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <div className="text-[11px] font-semibold text-slate-400 uppercase">
                  Linked Police / CAD Records
                </div>
                {veh.linkedIncidents.map(incId => (
                  <button
                    key={incId}
                    type="button"
                    onClick={() => onSelectIncidentById(incId)}
                    className="w-full text-left p-1.5 bg-slate-950 rounded hover:bg-slate-800 transition-colors flex items-center justify-between text-[11px] font-mono cursor-pointer"
                  >
                    <span className="text-cyan-400 font-semibold">{incId}</span>
                    <span className="text-slate-400 font-sans">View Record →</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Master Location / Premise Hazards (MLI) */}
      {activeTab === 'LOCATIONS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLocations.map(loc => (
            <div
              key={loc.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 text-xs"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm">{loc.address}</h3>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">{loc.zone}</div>
                </div>
                <span className="font-mono text-[10px] text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded">
                  {loc.id}
                </span>
              </div>

              <div className="text-slate-300">
                <span className="font-semibold text-slate-400">Occupant/Facility:</span> {loc.occupant}
              </div>

              {/* Premise Hazards */}
              <div className="space-y-1.5 pt-1 border-t border-slate-800">
                <div className="text-[11px] font-semibold text-amber-400 uppercase">
                  Known Premise Hazards
                </div>
                {loc.hazardFlags.map((flag, idx) => (
                  <div
                    key={idx}
                    className="text-amber-300 text-[11px] flex items-center gap-1.5 bg-amber-500/10 p-1.5 rounded border border-amber-500/20"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{flag}</span>
                  </div>
                ))}
              </div>

              {/* Linked Incident */}
              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <div className="text-[11px] font-semibold text-slate-400 uppercase">
                  Prior Calls For Service
                </div>
                {loc.linkedIncidents.map(incId => (
                  <button
                    key={incId}
                    type="button"
                    onClick={() => onSelectIncidentById(incId)}
                    className="w-full text-left p-1.5 bg-slate-950 rounded hover:bg-slate-800 transition-colors flex items-center justify-between text-[11px] font-mono cursor-pointer"
                  >
                    <span className="text-cyan-400 font-semibold">{incId}</span>
                    <span className="text-slate-400 font-sans">Open Case →</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
