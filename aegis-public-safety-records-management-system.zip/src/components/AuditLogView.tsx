import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { AuditActionType } from '../types/audit';
import {
  ShieldCheck,
  Search,
  Filter,
  Download,
  Terminal,
  Lock,
  Clock,
  UserCheck
} from 'lucide-react';

export const AuditLogView: React.FC = () => {
  const { auditLogs } = useRMS();

  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');

  const filteredLogs = auditLogs.filter(log => {
    if (actionFilter !== 'ALL' && log.action !== actionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        log.id.toLowerCase().includes(q) ||
        log.officerName.toLowerCase().includes(q) ||
        log.officerBadge.toLowerCase().includes(q) ||
        log.recordIdentifier.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Log ID', 'Timestamp', 'Officer Badge', 'Officer Name', 'Terminal IP', 'Action', 'Target Record', 'Details'];
    const rows = filteredLogs.map(l => [
      l.id,
      l.timestamp,
      l.officerBadge,
      `"${l.officerName}"`,
      `"${l.terminalIp}"`,
      l.action,
      l.recordIdentifier,
      `"${l.details.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `cjis_audit_log_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight">
              FBI CJIS Security Policy v5.9 Statutory Audit Trail
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Immutable logging of all Criminal Justice Information (CJI) views, edits, queries, and releases
            </p>
          </div>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-3.5 py-2 rounded-lg transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Audit Log (CSV)</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by badge, officer name, record identifier, or keyword..."
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg text-xs shrink-0 overflow-x-auto">
          {[
            'ALL',
            'RECORD_VIEW',
            'RECORD_CREATE',
            'RECORD_EDIT',
            'SUPERVISOR_APPROVAL',
            'EVIDENCE_CUSTODY_TRANSFER',
            'NCIC_CJIS_QUERY',
            'FOIA_PACKAGE_EXPORTED'
          ].map(action => (
            <button
              key={action}
              onClick={() => setActionFilter(action)}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                actionFilter === action
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {action === 'ALL'
                ? 'All Actions'
                : action === 'RECORD_VIEW'
                ? 'Views'
                : action === 'RECORD_CREATE'
                ? 'Creates'
                : action === 'SUPERVISOR_APPROVAL'
                ? 'Approvals'
                : action === 'EVIDENCE_CUSTODY_TRANSFER'
                ? 'Evidence'
                : action === 'NCIC_CJIS_QUERY'
                ? 'NCIC Queries'
                : 'FOIA'}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase">
              <tr>
                <th className="py-3 px-4">Event ID / Time</th>
                <th className="py-3 px-4">Officer / Badge</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Record Identifier</th>
                <th className="py-3 px-4">Workstation Terminal</th>
                <th className="py-3 px-4">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-850 transition-colors">
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-mono text-cyan-400 font-bold">{log.id}</div>
                    <div className="font-mono text-[11px] text-slate-500 tabular-nums">
                      {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="text-white font-medium">{log.officerName}</div>
                    <div className="font-mono text-[11px] text-slate-400">
                      Badge: {log.officerBadge}
                    </div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-mono text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-mono text-white font-semibold">
                      {log.recordIdentifier}
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap font-mono text-[11px] text-slate-400">
                    {log.terminalIp}
                  </td>
                  <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                    {log.details}
                  </td>
                </tr>
              ))}

              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                    No audit records match the selected criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
