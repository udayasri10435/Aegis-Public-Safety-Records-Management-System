import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { CADCallRecord } from '../types/cad';
import {
  Radio,
  FileCheck,
  Search,
  PlusCircle,
  Truck,
  Flame,
  Ambulance,
  Shield,
  CheckCircle2,
  Clock,
  Terminal,
  Send
} from 'lucide-react';

interface CADFeedViewProps {
  onIncidentCreatedFromCad: (incidentId: string) => void;
}

export const CADFeedView: React.FC<CADFeedViewProps> = ({ onIncidentCreatedFromCad }) => {
  const {
    cadCalls,
    activeAgencyFilter,
    convertCadToRms,
    queryNCIC
  } = useRMS();

  const [selectedCallId, setSelectedCallId] = useState<string>(cadCalls[0]?.callId || '');
  const [activeQueryTab, setActiveQueryTab] = useState<'WARRANT' | 'STOLEN_VEHICLE' | 'DRIVER_LICENSE'>('WARRANT');
  const [queryInput, setQueryInput] = useState<string>('Wallace, James');
  const [queryOutput, setQueryOutput] = useState<any | null>(null);
  const [isQuerying, setIsQuerying] = useState<boolean>(false);

  // Filter CAD calls
  const filteredCalls = cadCalls.filter(call => {
    if (activeAgencyFilter === 'ALL') return true;
    return call.agency === activeAgencyFilter;
  });

  const selectedCall = cadCalls.find(c => c.callId === selectedCallId) || filteredCalls[0];

  const handlePromoteToRMS = (call: CADCallRecord) => {
    try {
      const newReport = convertCadToRms(call.callId);
      onIncidentCreatedFromCad(newReport.id);
    } catch (err: any) {
      alert(`Error converting CAD call: ${err.message}`);
    }
  };

  const handleRunNCICQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryInput.trim()) return;
    setIsQuerying(true);
    setTimeout(() => {
      const res = queryNCIC(activeQueryTab, queryInput);
      setQueryOutput(res);
      setIsQuerying(false);
    }, 300);
  };

  const getPriorityLabel = (priority: number) => {
    switch (priority) {
      case 1:
        return 'P1 Emergency (Life Threatening)';
      case 2:
        return 'P2 Urgent';
      case 3:
        return 'P3 Standard Routine';
      default:
        return 'P4 Administrative';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / CAD Engine Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight">
              Computer Aided Dispatch (CAD) Telematics Bridge
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Live PSAP 911 dispatch queue · Bi-directional RMS ingestion · CJIS NCIC Terminal
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Total Active CAD Calls:</span>
          <span className="font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            {cadCalls.length}
          </span>
          <span className="text-slate-500">·</span>
          <span className="text-slate-400">RMS Sync Status:</span>
          <span className="text-emerald-400 font-medium flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Nominal
          </span>
        </div>
      </div>

      {/* Main 2-Column Split: Active Calls List on Left, Active Call Detail on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Call List (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-400 px-1">
            <span>DISPATCH QUEUE ({filteredCalls.length})</span>
            <span>SORT: PRIORITY / TIME</span>
          </div>

          <div className="space-y-2.5">
            {filteredCalls.map(call => {
              const isSelected = call.callId === selectedCall?.callId;
              const isTransferred = call.status === 'TRANSFERRED_TO_RMS';

              return (
                <div
                  key={call.callId}
                  onClick={() => setSelectedCallId(call.callId)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 ring-1 ring-cyan-500/30'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs font-mono font-bold ${
                          call.agency === 'POLICE'
                            ? 'text-cyan-400'
                            : call.agency === 'FIRE'
                            ? 'text-rose-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {call.callId}
                      </span>
                      <span className="text-slate-600">·</span>
                      <span className="text-xs font-semibold text-slate-200 truncate max-w-[180px]">
                        {call.callType}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                          call.priority === 1
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : call.priority === 2
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        P{call.priority}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-2 truncate">
                    {call.location}
                  </p>

                  <div className="flex items-center justify-between mt-3 text-[11px] text-slate-500 font-mono">
                    <div className="flex items-center gap-2">
                      <span>{call.units.length} Unit(s)</span>
                      <span>·</span>
                      <span>{call.units.map(u => u.unitId).slice(0, 2).join(', ')}</span>
                    </div>

                    {isTransferred ? (
                      <span className="text-emerald-400 font-sans font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Transferred to RMS
                      </span>
                    ) : (
                      <span className="text-amber-400 font-sans font-medium">
                        Pending RMS Promotion
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            {filteredCalls.length === 0 && (
              <div className="p-8 text-center bg-slate-900/40 rounded-xl border border-dashed border-slate-800 text-slate-400 text-xs">
                No active CAD dispatches matching the selected agency filter.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Selected Call Details & 1-Click Promote (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {selectedCall ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
              {/* Header with Call Meta */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                    <span className="text-cyan-400 font-bold">{selectedCall.callId}</span>
                    <span>·</span>
                    <span>CFS: {selectedCall.cfsCode}</span>
                    <span>·</span>
                    <span className="text-slate-300 font-sans">
                      {getPriorityLabel(selectedCall.priority)}
                    </span>
                  </div>
                  <h2 className="text-lg font-bold text-white mt-1">
                    {selectedCall.callType}
                  </h2>
                  <p className="text-xs text-slate-300 mt-1">
                    Location: <strong className="text-white">{selectedCall.location}</strong>
                    {selectedCall.crossStreet && ` (Cross: ${selectedCall.crossStreet})`}
                  </p>
                </div>

                {/* RMS Promote Action */}
                <div className="shrink-0">
                  {selectedCall.status === 'TRANSFERRED_TO_RMS' ? (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs px-3 py-2 rounded-lg font-medium">
                      <div className="flex items-center gap-1.5 font-bold">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Transferred to RMS</span>
                      </div>
                      <span className="font-mono text-[11px] block mt-0.5 text-slate-400">
                        Record #{selectedCall.rmsIncidentId}
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handlePromoteToRMS(selectedCall)}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 active:bg-cyan-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg transition-colors shadow-sm cursor-pointer"
                    >
                      <FileCheck className="w-4 h-4" />
                      <span>Promote to Formal RMS Case</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Dispatched Units Telematics Grid */}
              <div>
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
                  Assigned Public Safety Apparatus & Units ({selectedCall.units.length})
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedCall.units.map(unit => (
                    <div
                      key={unit.unitId}
                      className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        {unit.agency === 'FIRE' ? (
                          <Flame className="w-4 h-4 text-rose-400" />
                        ) : unit.agency === 'EMS' ? (
                          <Ambulance className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Shield className="w-4 h-4 text-cyan-400" />
                        )}
                        <div>
                          <div className="font-bold text-slate-200">{unit.unitId}</div>
                          <div className="text-[10px] text-slate-500 font-mono">
                            {unit.status}
                          </div>
                        </div>
                      </div>

                      <div className="text-right text-[11px] font-mono text-slate-400">
                        {unit.onSceneTime ? (
                          <span className="text-emerald-400">Scene: {unit.onSceneTime}</span>
                        ) : unit.enRouteTime ? (
                          <span className="text-cyan-400">En Route: {unit.enRouteTime}</span>
                        ) : (
                          <span>Disp: {unit.dispatchedTime}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 911 Caller & Dispatch Notes */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400 font-semibold uppercase tracking-wider">
                  <span>911 Telecommunicator Chronology</span>
                  <span className="font-mono text-[11px] text-slate-500">
                    Caller: {selectedCall.callerName} ({selectedCall.callerPhone})
                  </span>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-2.5 text-xs font-mono">
                  {selectedCall.notes.map((note, idx) => (
                    <div key={idx} className="border-b border-slate-900 last:border-0 pb-2 last:pb-0">
                      <div className="flex items-center gap-2 text-[11px] text-cyan-400 mb-0.5">
                        <Clock className="w-3 h-3" />
                        <span>{note.timestamp}</span>
                        <span>·</span>
                        <span>Op: {note.dispatcherId}</span>
                      </div>
                      <p className="text-slate-300 font-sans leading-relaxed">
                        {note.noteText}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs">
              Select a CAD call from the dispatch queue to view details.
            </div>
          )}

          {/* NCIC / CJIS Query Interactive Terminal */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                  NCIC / CJIS Real-Time Inquiry Terminal
                </h3>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                SECURE FED/STATE GATEWAY
              </span>
            </div>

            {/* Query Selector Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => {
                  setActiveQueryTab('WARRANT');
                  setQueryInput('Wallace, James');
                }}
                className={`flex-1 py-1.5 px-3 rounded-md font-medium transition-colors cursor-pointer ${
                  activeQueryTab === 'WARRANT'
                    ? 'bg-slate-800 text-cyan-400 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Wanted Person / Warrant
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveQueryTab('STOLEN_VEHICLE');
                  setQueryInput('8KLP491');
                }}
                className={`flex-1 py-1.5 px-3 rounded-md font-medium transition-colors cursor-pointer ${
                  activeQueryTab === 'STOLEN_VEHICLE'
                    ? 'bg-slate-800 text-cyan-400 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Stolen Vehicle / Plate
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveQueryTab('DRIVER_LICENSE');
                  setQueryInput('DL-W8920194');
                }}
                className={`flex-1 py-1.5 px-3 rounded-md font-medium transition-colors cursor-pointer ${
                  activeQueryTab === 'DRIVER_LICENSE'
                    ? 'bg-slate-800 text-cyan-400 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Driver License Record
              </button>
            </div>

            {/* Query Input Form */}
            <form onSubmit={handleRunNCICQuery} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  value={queryInput}
                  onChange={e => setQueryInput(e.target.value)}
                  placeholder={
                    activeQueryTab === 'WARRANT'
                      ? 'Enter Last, First Name or SSN...'
                      : activeQueryTab === 'STOLEN_VEHICLE'
                      ? 'Enter License Plate or VIN (e.g. 8KLP491)...'
                      : 'Enter DL Number (e.g. DL-W8920194)...'
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <button
                type="submit"
                disabled={isQuerying}
                className="bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 font-semibold text-xs px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isQuerying ? 'Querying...' : 'Query NCIC'}</span>
              </button>
            </form>

            {/* Output Screen */}
            {queryOutput && (
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 font-mono text-xs space-y-1.5">
                <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-900">
                  <span className="text-slate-500">ORIG: {queryOutput.agencyOrigin}</span>
                  <span
                    className={`font-bold ${
                      queryOutput.status === 'CAUTION_WARRANT' || queryOutput.status === 'HIT_FOUND'
                        ? 'text-rose-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    STATUS: {queryOutput.status}
                  </span>
                </div>
                <div className="text-slate-300 leading-relaxed pt-1">
                  {queryOutput.details}
                </div>
                <div className="text-[10px] text-slate-600 pt-1">
                  LOGGED UNDER CJIS AUDIT TRAIL · COMPLIANT WITH 28 CFR PART 20
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
