import React from 'react';
import { IncidentReport } from '../types/rms';
import { X, Printer, Shield, ShieldCheck, Download } from 'lucide-react';

interface PrintableIncidentModalProps {
  incident: IncidentReport | null;
  onClose: () => void;
}

export const PrintableIncidentModal: React.FC<PrintableIncidentModalProps> = ({
  incident,
  onClose
}) => {
  if (!incident) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[95vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Controls Bar */}
        <div className="no-print px-6 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-cyan-400 font-bold">{incident.id}</span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-300">Department Master Case Jacket</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-4 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="flex-1 overflow-y-auto p-8 bg-white text-black font-sans text-xs space-y-6">
          {/* Official Department Header */}
          <div className="border-b-2 border-black pb-4 flex items-start justify-between">
            <div className="space-y-1">
              <div className="text-base font-extrabold tracking-tight uppercase">
                METROPOLITAN PUBLIC SAFETY ADMINISTRATION
              </div>
              <div className="text-xs font-semibold uppercase text-neutral-800">
                {incident.agency === 'POLICE'
                  ? 'DEPARTMENT OF POLICE · RECORDS & IDENTIFICATION DIVISION'
                  : incident.agency === 'FIRE'
                  ? 'FIRE & RESCUE SERVICE · ARSON & INVESTIGATION BUREAU'
                  : 'EMERGENCY MEDICAL SERVICES · ePCR CLINICAL DIVISION'}
              </div>
              <div className="text-[10px] text-neutral-600 font-mono">
                CJIS COMPLIANT RECORD · OFFICIAL MUNICIPAL DOCUMENT
              </div>
            </div>

            <div className="text-right font-mono space-y-0.5">
              <div className="text-sm font-bold tracking-wider">{incident.id}</div>
              {incident.cadCallId && (
                <div className="text-[11px] text-neutral-600">CAD Ref: {incident.cadCallId}</div>
              )}
              <div className="text-[10px] text-neutral-500">
                Generated: {new Date().toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Core Case Particulars Table */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-neutral-100 p-3 rounded border border-neutral-300">
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Incident Type</div>
              <div className="font-bold text-neutral-900 mt-0.5">{incident.incidentType}</div>
            </div>
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Statutory Standard Code</div>
              <div className="font-mono font-bold text-neutral-900 mt-0.5">{incident.codeNibrsOrClass}</div>
            </div>
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Status / Verification</div>
              <div className="font-bold text-emerald-700 mt-0.5">{incident.status}</div>
            </div>
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Beat / Fire Sector</div>
              <div className="font-bold text-neutral-900 mt-0.5">{incident.zoneBeat}</div>
            </div>
          </div>

          {/* Location and Primary Timestamps */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 border border-neutral-200 p-3 rounded">
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Occurrence Location</div>
              <div className="font-semibold text-neutral-900 mt-0.5">{incident.locationAddress}</div>
            </div>
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Reported Date / Time</div>
              <div className="font-mono text-neutral-800 mt-0.5">
                {new Date(incident.reportedDate).toLocaleString()}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-semibold">Reporting Officer</div>
              <div className="font-semibold text-neutral-900 mt-0.5">
                {incident.reportingOfficerName} (Badge #{incident.reportingOfficerBadge})
              </div>
            </div>
          </div>

          {/* Involved Persons */}
          {incident.persons.length > 0 && (
            <div className="space-y-2">
              <div className="font-bold text-xs uppercase tracking-wider border-b border-black pb-1">
                Involved Parties & Statements ({incident.persons.length})
              </div>
              <div className="divide-y divide-neutral-200 border border-neutral-200 rounded overflow-hidden">
                {incident.persons.map((p, idx) => (
                  <div key={idx} className="p-2.5 grid grid-cols-1 sm:grid-cols-4 gap-2 text-[11px]">
                    <div>
                      <span className="font-bold font-mono text-neutral-600">[{p.role}]</span>{' '}
                      <span className="font-semibold text-neutral-900">{p.fullName}</span>
                    </div>
                    <div className="font-mono text-neutral-600">
                      DOB: {p.dob} · SSN: {p.ssnMasked}
                    </div>
                    <div className="text-neutral-700 truncate">{p.address}</div>
                    <div className="text-neutral-600 font-mono">{p.phone}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Fire Specific Extension if Present */}
          {incident.fireData && (
            <div className="space-y-2">
              <div className="font-bold text-xs uppercase tracking-wider border-b border-black pb-1">
                NFIRS 5.0 Fire Service Summary
              </div>
              <div className="grid grid-cols-3 gap-3 p-3 bg-neutral-50 border border-neutral-200 rounded text-[11px]">
                <div>
                  <span className="font-semibold text-neutral-600">Property Use:</span>{' '}
                  {incident.fireData.propertyUse}
                </div>
                <div>
                  <span className="font-semibold text-neutral-600">Cause of Ignition:</span>{' '}
                  {incident.fireData.causeOfIgnition}
                </div>
                <div>
                  <span className="font-semibold text-neutral-600">Estimated Loss:</span>{' '}
                  ${incident.fireData.estimatedLossDollars.toLocaleString()}
                </div>
                <div className="col-span-3">
                  <span className="font-semibold text-neutral-600">Apparatus Dispatched:</span>{' '}
                  {incident.fireData.apparatusAssigned.join(', ')}
                </div>
              </div>
            </div>
          )}

          {/* EMS Specific Extension if Present */}
          {incident.emsData && (
            <div className="space-y-2">
              <div className="font-bold text-xs uppercase tracking-wider border-b border-black pb-1">
                NEMSIS v3.5 Emergency Medical ePCR Report
              </div>
              <div className="p-3 bg-neutral-50 border border-neutral-200 rounded space-y-2 text-[11px]">
                <div>
                  <span className="font-semibold text-neutral-600">Chief Complaint:</span>{' '}
                  {incident.emsData.chiefComplaint}
                </div>
                <div>
                  <span className="font-semibold text-neutral-600">Destination Hospital:</span>{' '}
                  {incident.emsData.transportHospital}
                </div>
                {/* Vitals Table */}
                <div className="pt-1">
                  <div className="font-semibold text-neutral-700 mb-1">Acquired Patient Vitals:</div>
                  <table className="w-full text-left font-mono text-[10px]">
                    <thead className="bg-neutral-200 text-neutral-700">
                      <tr>
                        <th className="p-1">Time</th>
                        <th className="p-1">BP (mmHg)</th>
                        <th className="p-1">Pulse (bpm)</th>
                        <th className="p-1">Resp</th>
                        <th className="p-1">SpO2 (%)</th>
                        <th className="p-1">GCS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {incident.emsData.vitals.map((v, i) => (
                        <tr key={i} className="border-b border-neutral-200">
                          <td className="p-1">{v.timestamp}</td>
                          <td className="p-1">{v.bpSystolic}/{v.bpDiastolic}</td>
                          <td className="p-1">{v.pulseRate}</td>
                          <td className="p-1">{v.respiratoryRate}</td>
                          <td className="p-1">{v.spo2Percent}%</td>
                          <td className="p-1">{v.gcsTotal}/15</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Officer Narrative */}
          <div className="space-y-1.5">
            <div className="font-bold text-xs uppercase tracking-wider border-b border-black pb-1">
              Officer Chronological Report & Probable Cause Synopsis
            </div>
            <div className="p-3 bg-neutral-50 border border-neutral-200 rounded font-mono text-[11px] leading-relaxed whitespace-pre-wrap">
              {incident.narrativeText}
            </div>
          </div>

          {/* Linked Evidence */}
          {incident.linkedEvidenceIds.length > 0 && (
            <div className="space-y-1">
              <div className="font-bold text-xs uppercase tracking-wider">
                Chain of Custody Evidence Barcodes
              </div>
              <div className="flex flex-wrap gap-2 text-[11px] font-mono">
                {incident.linkedEvidenceIds.map(evId => (
                  <span key={evId} className="px-2 py-0.5 bg-neutral-100 border border-neutral-300 rounded font-bold">
                    {evId}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Signatures & Certification Block */}
          <div className="pt-6 border-t-2 border-black grid grid-cols-2 gap-8 text-[11px]">
            <div>
              <div className="border-b border-black pb-1 font-semibold">
                {incident.reportingOfficerName}
              </div>
              <div className="flex justify-between text-neutral-600 mt-1">
                <span>Reporting Officer (Badge #{incident.reportingOfficerBadge})</span>
                <span className="font-mono">{new Date(incident.reportedDate).toLocaleDateString()}</span>
              </div>
            </div>

            <div>
              <div className="border-b border-black pb-1 font-semibold">
                {incident.supervisorName || 'Sgt. Elena Rodriguez (Signed Electronically)'}
              </div>
              <div className="flex justify-between text-neutral-600 mt-1">
                <span>Supervisory Approval (Badge #{incident.supervisorBadge || 'PD-1102'})</span>
                <span className="font-mono">
                  {incident.supervisorApprovalDate
                    ? new Date(incident.supervisorApprovalDate).toLocaleDateString()
                    : new Date().toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
