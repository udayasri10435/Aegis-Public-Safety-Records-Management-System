import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import {
  FOIARequestRecord,
  RedactionMark,
  StatutoryExemptionCode
} from '../types/foia';
import {
  FileLock2,
  Search,
  CheckCircle,
  Eye,
  ShieldAlert,
  Sparkles,
  Download,
  Printer,
  Trash2,
  Lock,
  Calendar,
  AlertCircle,
  Building,
  FileText
} from 'lucide-react';

export const FOIAStudioView: React.FC = () => {
  const {
    foiaRequests,
    incidents,
    updateFOIARedactions,
    releaseFOIAPackage
  } = useRMS();

  const [selectedRequestId, setSelectedRequestId] = useState<string>(
    foiaRequests[0]?.requestId || ''
  );
  const [activeExemption, setActiveExemption] = useState<StatutoryExemptionCode>('PRIVACY_552_B7C');
  const [viewMode, setViewMode] = useState<'MARKING' | 'PUBLIC_PREVIEW'>('MARKING');
  const [isExportCertModalOpen, setIsExportCertModalOpen] = useState(false);

  const selectedRequest =
    foiaRequests.find(r => r.requestId === selectedRequestId) || foiaRequests[0];

  const targetIncident = incidents.find(
    i => i.id === selectedRequest?.targetIncidentId
  );

  const exemptionDefinitions: {
    code: StatutoryExemptionCode;
    label: string;
    description: string;
  }[] = [
    {
      code: 'PRIVACY_552_B7C',
      label: '5 U.S.C. § 552(b)(7)(C) - Privacy',
      description: 'Protects personal privacy of victims, witnesses, and third parties.'
    },
    {
      code: 'JUVENILE_RECORD',
      label: 'Juvenile Statutory Safe Harbor',
      description: 'Mandatory seal for minors under 18 years of age.'
    },
    {
      code: 'CJIS_PII_SSN',
      label: 'CJIS / PII (SSN, DL, Financial)',
      description: 'Criminal Justice Information & sensitive personally identifiable data.'
    },
    {
      code: 'ACTIVE_INVESTIGATION_552_B7A',
      label: '5 U.S.C. § 552(b)(7)(A) - Enforcement',
      description: 'Prevents interference with active, pending law enforcement trials.'
    },
    {
      code: 'HIPAA_MEDICAL_164',
      label: 'HIPAA 45 CFR § 164.512 - Medical',
      description: 'Protected EMS patient clinical information and diagnoses.'
    },
    {
      code: 'VICTIM_MARSY_LAW',
      label: "Marsy's Law / Victim Confidentiality",
      description: 'Protects contact details and addresses of violent crime victims.'
    }
  ];

  // Auto-Detect PII and common statutory exemptions
  const handleAutoDetectRedactions = () => {
    if (!targetIncident || !selectedRequest) return;

    const narrative = targetIncident.narrativeText;
    const newRedactions: RedactionMark[] = [...selectedRequest.redactions];

    // Regular expressions for SSN, phone, DOB, and specific victim/juvenile names
    const patterns: { regex: RegExp; code: StatutoryExemptionCode; label: string }[] = [
      {
        regex: /XXX-XX-\d{4}|\d{3}-\d{2}-\d{4}/gi,
        code: 'CJIS_PII_SSN',
        label: 'CJIS PII / Social Security'
      },
      {
        regex: /\(\d{3}\)\s*\d{3}-\d{4}/gi,
        code: 'PRIVACY_552_B7C',
        label: '5 U.S.C. § 552(b)(7)(C) - Phone'
      },
      {
        regex: /DOB:\s*\d{2}\/\d{2}\/\d{4}/gi,
        code: 'PRIVACY_552_B7C',
        label: 'Date of Birth Exemption'
      },
      {
        regex: /juvenile\s+male\s*\(\d+yo[^)]*\)/gi,
        code: 'JUVENILE_RECORD',
        label: 'Juvenile Identity Protection'
      }
    ];

    patterns.forEach(({ regex, code, label }) => {
      let match;
      while ((match = regex.exec(narrative)) !== null) {
        const text = match[0];
        const start = match.index;
        const end = start + text.length;

        const alreadyExists = newRedactions.some(
          r => r.startIndex === start && r.endIndex === end
        );

        if (!alreadyExists) {
          newRedactions.push({
            id: `RED-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            startIndex: start,
            endIndex: end,
            originalText: text,
            exemptionCode: code,
            exemptionLabel: label,
            redactedReplacementText: `[REDACTED: ${label}]`
          });
        }
      }
    });

    updateFOIARedactions(selectedRequest.requestId, newRedactions);
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0 || !selectedRequest || !targetIncident) return;

    const selectedText = selection.toString().trim();
    if (!selectedText || selectedText.length < 2) return;

    const narrative = targetIncident.narrativeText;
    const startIndex = narrative.indexOf(selectedText);
    if (startIndex === -1) return;

    const endIndex = startIndex + selectedText.length;
    const currentExemption = exemptionDefinitions.find(e => e.code === activeExemption)!;

    const newMark: RedactionMark = {
      id: `RED-${Date.now()}`,
      startIndex,
      endIndex,
      originalText: selectedText,
      exemptionCode: activeExemption,
      exemptionLabel: currentExemption.label,
      redactedReplacementText: `[REDACTED: ${currentExemption.label}]`
    };

    updateFOIARedactions(selectedRequest.requestId, [
      ...selectedRequest.redactions,
      newMark
    ]);

    selection.removeAllRanges();
  };

  const handleRemoveRedaction = (redactionId: string) => {
    if (!selectedRequest) return;
    const filtered = selectedRequest.redactions.filter(r => r.id !== redactionId);
    updateFOIARedactions(selectedRequest.requestId, filtered);
  };

  const handleReleaseDisclosure = () => {
    if (!selectedRequest) return;
    const certNum = `SEAL-${new Date().getFullYear()}-FOIA-${Math.floor(1000 + Math.random() * 9000)}`;
    releaseFOIAPackage(selectedRequest.requestId, certNum, 'RECORDS-OFFICER-09');
    setIsExportCertModalOpen(false);
  };

  // Render text with redaction highlights or blacked out blocks
  const renderRedactedNarrative = () => {
    if (!targetIncident) return <p className="text-slate-500">No incident loaded.</p>;

    const narrative = targetIncident.narrativeText;
    const redactions = selectedRequest ? [...selectedRequest.redactions] : [];

    if (redactions.length === 0) {
      return (
        <div
          onMouseUp={handleTextSelection}
          className="text-slate-200 font-mono text-xs leading-relaxed whitespace-pre-wrap select-text cursor-text"
        >
          {narrative}
        </div>
      );
    }

    // Sort by startIndex
    redactions.sort((a, b) => a.startIndex - b.startIndex);

    let lastIndex = 0;
    const elements: React.ReactNode[] = [];

    redactions.forEach((r, idx) => {
      // Add text preceding redaction
      if (r.startIndex > lastIndex) {
        elements.push(
          <span key={`text-${idx}`} className="text-slate-200">
            {narrative.substring(lastIndex, r.startIndex)}
          </span>
        );
      }

      // Add redaction element
      if (viewMode === 'MARKING') {
        elements.push(
          <mark
            key={`red-${r.id}`}
            title={`${r.exemptionLabel} - Click to delete`}
            onClick={() => handleRemoveRedaction(r.id)}
            className="bg-amber-500/20 text-amber-200 border-b-2 border-amber-400 px-1 py-0.5 rounded cursor-pointer mx-0.5 hover:bg-rose-500/30 transition-colors"
          >
            {r.originalText}
            <span className="text-[10px] text-amber-300 font-mono ml-1 font-bold">
              [{r.exemptionCode.split('_')[0]}]
            </span>
          </mark>
        );
      } else {
        // Public Preview: Blacked out bar with clean legal citation
        elements.push(
          <span
            key={`red-${r.id}`}
            className="inline-block bg-black text-amber-400/90 font-mono text-[11px] px-1.5 py-0.5 border border-slate-700 mx-1 rounded-xs"
          >
            {r.redactedReplacementText}
          </span>
        );
      }

      lastIndex = r.endIndex;
    });

    // Add trailing text
    if (lastIndex < narrative.length) {
      elements.push(
        <span key="text-end" className="text-slate-200">
          {narrative.substring(lastIndex)}
        </span>
      );
    }

    return (
      <div
        onMouseUp={handleTextSelection}
        className="font-mono text-xs leading-relaxed whitespace-pre-wrap select-text cursor-text"
      >
        {elements}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <FileLock2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight">
              FOIA & Public Records Statutory Redaction Studio
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Freedom of Information Act · State Public Records Act · Statutory Exemptions & Legal Disclosure
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selectedRequest?.status === 'RELEASED_SANITIZED' ? (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Released: Seal #{selectedRequest.certificationSealNumber}</span>
            </div>
          ) : (
            <button
              onClick={() => setIsExportCertModalOpen(true)}
              className="inline-flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Certify & Release Disclosure</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Request Queue (4 cols) & Redaction Workspace (8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: FOIA Request Queue (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-400 px-1">
            <span>PUBLIC RECORDS REQUESTS ({foiaRequests.length})</span>
            <span>STATUTORY DEADLINE</span>
          </div>

          <div className="space-y-2.5">
            {foiaRequests.map(req => {
              const isSelected = req.requestId === selectedRequest?.requestId;
              return (
                <div
                  key={req.requestId}
                  onClick={() => setSelectedRequestId(req.requestId)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 ring-1 ring-cyan-500/30'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-cyan-400">
                      {req.requestId}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        req.status === 'RELEASED_SANITIZED'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : req.status === 'IN_REDACTION'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {req.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="mt-1.5">
                    <div className="text-xs font-semibold text-white">
                      {req.requestorName}
                    </div>
                    {req.requestorOrganization && (
                      <div className="text-[11px] text-slate-400">
                        {req.requestorOrganization}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between mt-2.5 text-[11px] text-slate-400 border-t border-slate-800/60 pt-2 font-sans">
                    <span>Target: <strong className="font-mono text-slate-300">{req.targetIncidentId}</strong></span>
                    <span className="text-slate-600">·</span>
                    <span className="text-amber-400 font-mono">
                      Due: {new Date(req.statutoryDueDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Redaction Studio Workspace (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {selectedRequest && targetIncident ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
              {/* Studio Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="text-cyan-400 font-bold">{selectedRequest.requestId}</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-300">Target Case: {targetIncident.id}</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-400">{selectedRequest.recordTypeRequested}</span>
                  </div>
                  <h2 className="text-base font-bold text-white mt-1">
                    Redaction Workspace: {targetIncident.title}
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Requestor: {selectedRequest.requestorName} ({selectedRequest.requestorEmail})
                  </p>
                </div>

                {/* View Mode Toggle */}
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg text-xs self-start shrink-0">
                  <button
                    onClick={() => setViewMode('MARKING')}
                    className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                      viewMode === 'MARKING'
                        ? 'bg-slate-800 text-cyan-400 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Marking Studio
                  </button>
                  <button
                    onClick={() => setViewMode('PUBLIC_PREVIEW')}
                    className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                      viewMode === 'PUBLIC_PREVIEW'
                        ? 'bg-slate-800 text-cyan-400 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Public Sanitized Preview
                  </button>
                </div>
              </div>

              {/* Exemption Palette & Auto-Detect Controls */}
              <div className="space-y-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300">
                    Statutory Exemption Brush (Highlight text in document below to redact):
                  </span>
                  <button
                    onClick={handleAutoDetectRedactions}
                    className="inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto-Detect PII & Juveniles</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {exemptionDefinitions.map(ex => {
                    const isBrushActive = activeExemption === ex.code;
                    return (
                      <button
                        key={ex.code}
                        type="button"
                        onClick={() => setActiveExemption(ex.code)}
                        className={`text-left p-2 rounded-lg border text-xs transition-all cursor-pointer ${
                          isBrushActive
                            ? 'bg-cyan-500/10 border-cyan-500 text-cyan-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <div className="font-bold truncate">{ex.label}</div>
                        <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                          {ex.description}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Redacted Document Canvas */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
                  <span>OFFICER NARRATIVE DOCUMENT ({selectedRequest.redactions.length} Masks Applied)</span>
                  {viewMode === 'MARKING' && (
                    <span className="text-amber-400 text-[11px]">
                      Select text with mouse to apply current brush
                    </span>
                  )}
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl min-h-[220px]">
                  {renderRedactedNarrative()}
                </div>
              </div>

              {/* Applied Redactions Ledger */}
              {selectedRequest.redactions.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Statutory Redaction Index ({selectedRequest.redactions.length})
                  </h4>
                  <div className="max-h-40 overflow-y-auto space-y-1.5 divide-y divide-slate-800/40">
                    {selectedRequest.redactions.map(r => (
                      <div
                        key={r.id}
                        className="pt-1.5 flex items-center justify-between text-xs text-slate-300"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-cyan-400 font-semibold">
                            "{r.originalText}"
                          </span>
                          <span className="text-slate-600">→</span>
                          <span className="text-amber-400 font-mono text-[11px]">
                            {r.exemptionLabel}
                          </span>
                        </div>
                        <button
                          onClick={() => handleRemoveRedaction(r.id)}
                          className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                          title="Remove Redaction"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-xl text-slate-400 text-xs">
              Select a FOIA request from the queue to open the redaction studio.
            </div>
          )}
        </div>
      </div>

      {/* Certify & Release Modal */}
      {isExportCertModalOpen && selectedRequest && targetIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl p-6 space-y-5 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">
                Certify FOIA Public Disclosure Packet
              </h3>
              <button
                onClick={() => setIsExportCertModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-white text-black p-5 rounded-lg border-2 border-slate-300 space-y-3 font-sans">
              <div className="text-center border-b-2 border-black pb-2">
                <div className="text-xs font-bold uppercase tracking-wider">
                  CERTIFICATE OF PUBLIC RECORDS DISCLOSURE
                </div>
                <div className="text-[10px] text-neutral-600">
                  ISSUED UNDER THE FREEDOM OF INFORMATION & PUBLIC RECORDS ACT
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <div><strong>REQUEST IDENTIFIER:</strong> {selectedRequest.requestId}</div>
                <div><strong>REQUESTOR:</strong> {selectedRequest.requestorName} ({selectedRequest.requestorOrganization || 'Individual Citizen'})</div>
                <div><strong>TARGET CASE:</strong> {targetIncident.id} ({targetIncident.incidentType})</div>
                <div><strong>TOTAL STATUTORY EXEMPTIONS APPLIED:</strong> {selectedRequest.redactions.length}</div>
              </div>

              <div className="pt-2 text-[10px] text-neutral-700 border-t border-neutral-300">
                I hereby certify under penalty of law that the accompanying public records have been reviewed by authorized records personnel, and that all withholdings are justified under applicable state and federal statutory exemptions.
              </div>

              <div className="flex justify-between items-end pt-3 text-[11px]">
                <div>
                  <div className="font-mono">SEAL: SEAL-2026-DISCLOSE-CERT</div>
                  <div className="text-[10px] text-neutral-500">Date: {new Date().toLocaleDateString()}</div>
                </div>
                <div className="text-right border-t border-black pt-1 px-4">
                  <div>Authorized Records Custodian</div>
                  <div className="font-mono text-[10px]">Badge #RECORDS-09</div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsExportCertModalOpen(false)}
                className="px-4 py-2 text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleReleaseDisclosure}
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-4 py-2 rounded-lg cursor-pointer"
              >
                Sign & Finalize Release
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
