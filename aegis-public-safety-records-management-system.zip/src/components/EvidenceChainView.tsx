import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { EvidenceItem, CustodyAction, EvidenceCategory } from '../types/evidence';
import {
  PackageCheck,
  Search,
  Plus,
  ShieldCheck,
  QrCode,
  FileCheck2,
  Lock,
  ArrowRightLeft,
  CheckCircle2,
  Clock,
  Printer,
  X,
  FileText,
  Video,
  AlertTriangle
} from 'lucide-react';

export const EvidenceChainView: React.FC = () => {
  const { evidence, addEvidence, transferEvidenceCustody } = useRMS();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [selectedBarcode, setSelectedBarcode] = useState<string>(evidence[0]?.trackingBarcode || '');
  
  // Modals
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isNewEvidenceModalOpen, setIsNewEvidenceModalOpen] = useState(false);
  const [isPrintLabelOpen, setIsPrintLabelOpen] = useState(false);

  // Transfer form state
  const [transferAction, setTransferAction] = useState<CustodyAction>('CHECKED_OUT_LAB');
  const [receivedByName, setReceivedByName] = useState('Criminalist D. Sterling');
  const [receivedByBadge, setReceivedByBadge] = useState('LAB-409');
  const [agencyDivision, setAgencyDivision] = useState('County Forensics / Ballistics Unit');
  const [purposeReason, setPurposeReason] = useState('Ballistic comparison and latent fingerprint chemical etching');
  const [tamperSealIntact, setTamperSealIntact] = useState(true);

  // New Evidence state
  const [newIncidentId, setNewIncidentId] = useState('2026-PD-08942');
  const [newCategory, setNewCategory] = useState<EvidenceCategory>('WEAPON_FIREARM');
  const [newDescription, setNewDescription] = useState('');
  const [newStorageLocation, setNewStorageLocation] = useState('Property Vault B / Shelf 3 / Bin 14');
  const [newOfficer, setNewOfficer] = useState('Marcus Vance');
  const [newBadge, setNewBadge] = useState('PD-4819');

  // Filter evidence
  const filteredEvidence = evidence.filter(item => {
    if (categoryFilter !== 'ALL' && item.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.trackingBarcode.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.incidentId.toLowerCase().includes(q) ||
        item.storageLockerLocation.toLowerCase().includes(q) ||
        item.currentCustodian.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const selectedItem = evidence.find(e => e.trackingBarcode === selectedBarcode) || filteredEvidence[0];

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    transferEvidenceCustody(selectedItem.trackingBarcode, {
      action: transferAction,
      releasedByName: 'Property Officer D. Alvarez',
      releasedByBadge: 'PD-092',
      receivedByName,
      receivedByBadge,
      agencyDivision,
      purposeReason,
      tamperSealIntact
    });

    setIsTransferModalOpen(false);
  };

  const handleCreateEvidence = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDescription.trim()) return;

    const randNum = Math.floor(1000 + Math.random() * 9000);
    const generatedBarcode = `EV-2026-${randNum}-01`;

    // Generate pseudo SHA-256 for demo integrity
    const generatedHash = Array.from({ length: 64 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');

    const newItem: EvidenceItem = {
      trackingBarcode: generatedBarcode,
      incidentId: newIncidentId,
      category: newCategory,
      description: newDescription,
      storageLockerLocation: newStorageLocation,
      dateCollected: new Date().toISOString(),
      collectedByOfficer: newOfficer,
      collectedByBadge: newBadge,
      currentCustodian: `${newOfficer} (${newBadge})`,
      status: 'IN_VAULT',
      sha256Hash: generatedHash,
      chainOfCustody: [
        {
          id: `CH-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toISOString(),
          action: 'RECOVERED_AT_SCENE',
          releasedByBadge: 'SCENE',
          releasedByName: 'Scene Recovery',
          receivedByBadge: newBadge,
          receivedByName: newOfficer,
          agencyDivision: 'Patrol Operations',
          purposeReason: 'Field collection and initial packaging into tamper-proof container',
          tamperSealIntact: true,
          signatureVerificationId: `SIG-${newBadge}-INIT`
        }
      ]
    };

    addEvidence(newItem);
    setSelectedBarcode(generatedBarcode);
    setIsNewEvidenceModalOpen(false);
    setNewDescription('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <PackageCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight">
              Evidence Room & Cryptographic Chain of Custody
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              CJIS Security Policy v5.9 · Automated SHA-256 Tamper Verification · Property Room Barcoding
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsNewEvidenceModalOpen(true)}
          className="inline-flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition-colors shadow-sm self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Log Evidence Item</span>
        </button>
      </div>

      {/* Main 2-Column Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Evidence Inventory (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Search & Filter */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search barcode, case #, item description..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center gap-1 text-[11px] overflow-x-auto pb-0.5">
              {['ALL', 'WEAPON_FIREARM', 'DIGITAL_BWC_VIDEO', 'CURRENCY', 'PROPERTY_IMPOUND'].map(
                cat => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`px-2 py-1 rounded whitespace-nowrap transition-colors cursor-pointer ${
                      categoryFilter === cat
                        ? 'bg-slate-800 text-cyan-400 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat === 'ALL'
                      ? 'All'
                      : cat === 'WEAPON_FIREARM'
                      ? 'Firearms'
                      : cat === 'DIGITAL_BWC_VIDEO'
                      ? 'BWC Video'
                      : cat === 'CURRENCY'
                      ? 'Currency'
                      : 'Impound'}
                  </button>
                )
              )}
            </div>
          </div>

          {/* List items */}
          <div className="space-y-2">
            {filteredEvidence.map(item => {
              const isSelected = item.trackingBarcode === selectedItem?.trackingBarcode;
              return (
                <div
                  key={item.trackingBarcode}
                  onClick={() => setSelectedBarcode(item.trackingBarcode)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 ring-1 ring-cyan-500/30'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-cyan-400">
                      {item.trackingBarcode}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        item.status === 'IN_VAULT'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : item.status === 'OUT_AT_LAB'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {item.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <p className="text-xs text-slate-200 font-medium mt-1.5 line-clamp-2">
                    {item.description}
                  </p>

                  <div className="flex items-center justify-between mt-2.5 text-[11px] text-slate-400 font-sans border-t border-slate-800/60 pt-2">
                    <span>Case: <strong className="text-slate-300 font-mono">{item.incidentId}</strong></span>
                    <span className="text-slate-600">·</span>
                    <span className="truncate max-w-[150px]">{item.storageLockerLocation}</span>
                  </div>
                </div>
              );
            })}

            {filteredEvidence.length === 0 && (
              <div className="p-8 text-center bg-slate-900/40 rounded-xl border border-dashed border-slate-800 text-slate-400 text-xs">
                No evidence items match the specified query.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Selected Item Detail & Chain of Custody Ledger (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {selectedItem ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
              {/* Header with actions */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="text-cyan-400 font-bold">{selectedItem.trackingBarcode}</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-400">Case #{selectedItem.incidentId}</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-400">{selectedItem.category.replace(/_/g, ' ')}</span>
                  </div>
                  <h2 className="text-base font-bold text-white mt-1">
                    {selectedItem.description}
                  </h2>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setIsPrintLabelOpen(true)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                    title="Print Evidence Barcode Label"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Label</span>
                  </button>

                  <button
                    onClick={() => setIsTransferModalOpen(true)}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>Transfer Custody</span>
                  </button>
                </div>
              </div>

              {/* Physical Vault & Custodian Metadata */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                <div>
                  <div className="text-slate-500">Storage Location</div>
                  <div className="text-white font-medium mt-0.5">{selectedItem.storageLockerLocation}</div>
                </div>
                <div>
                  <div className="text-slate-500">Current Custodian</div>
                  <div className="text-white font-medium mt-0.5">{selectedItem.currentCustodian}</div>
                </div>
                <div>
                  <div className="text-slate-500">Intake Officer</div>
                  <div className="text-white font-medium mt-0.5">
                    {selectedItem.collectedByOfficer} ({selectedItem.collectedByBadge})
                  </div>
                </div>
              </div>

              {/* Cryptographic SHA-256 Tamper Verification Box */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                    <ShieldCheck className="w-4 h-4" />
                    <span>CJIS Cryptographic Integrity Verification</span>
                  </div>
                  <span className="font-mono text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    HASH VERIFIED & MATCHED
                  </span>
                </div>
                <div className="font-mono text-[11px] text-slate-400 break-all bg-slate-900/80 p-2 rounded border border-slate-800">
                  SHA-256: <span className="text-cyan-300">{selectedItem.sha256Hash}</span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Calculated against digital archive / tamper-sealed field envelope. Guarantees zero post-seizure alterations.
                </div>
              </div>

              {/* Chain of Custody Timeline Ledger */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  <span>Chain of Custody Events Ledger ({selectedItem.chainOfCustody.length})</span>
                  <span className="font-mono text-[11px] text-slate-500">CJIS 28 CFR COMPLIANT</span>
                </div>

                <div className="space-y-2.5">
                  {selectedItem.chainOfCustody.map((event, idx) => (
                    <div
                      key={event.id || idx}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-cyan-400">
                            {event.action.replace(/_/g, ' ')}
                          </span>
                          <span className="text-slate-600">·</span>
                          <span className="text-slate-400 font-mono">
                            {new Date(event.timestamp).toLocaleString()}
                          </span>
                        </div>

                        {event.tamperSealIntact ? (
                          <span className="text-emerald-400 text-[11px] flex items-center gap-1 font-medium">
                            <CheckCircle2 className="w-3 h-3" /> Seal Intact
                          </span>
                        ) : (
                          <span className="text-rose-400 text-[11px] flex items-center gap-1 font-medium">
                            <AlertTriangle className="w-3 h-3" /> Seal Broken / Inspection
                          </span>
                        )}
                      </div>

                      <div className="text-slate-300">
                        Released by <strong className="text-white">{event.releasedByName}</strong> ({event.releasedByBadge}) 
                        {' '}→ Received by <strong className="text-white">{event.receivedByName}</strong> ({event.receivedByBadge})
                      </div>

                      <div className="text-slate-400 text-[11px]">
                        Purpose / Destination: {event.purposeReason} ({event.agencyDivision})
                      </div>

                      <div className="font-mono text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                        VERIFICATION SIGNATURE ID: {event.signatureVerificationId}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-xl text-slate-400 text-xs">
              Select an evidence item to review its chain of custody.
            </div>
          )}
        </div>
      </div>

      {/* Transfer Custody Modal */}
      {isTransferModalOpen && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-5 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Execute Chain of Custody Transfer</h3>
                <p className="text-xs font-mono text-cyan-400 mt-0.5">{selectedItem.trackingBarcode}</p>
              </div>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Transfer Action</label>
                <select
                  value={transferAction}
                  onChange={e => setTransferAction(e.target.value as CustodyAction)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white focus:outline-none"
                >
                  <option value="CHECKED_OUT_LAB">Check Out to Forensics / Crime Lab</option>
                  <option value="CHECKED_OUT_COURT">Check Out for Court Subpoena Exhibit</option>
                  <option value="TRANSFERRED_CUSTODIAN">Transfer Custodian / Detective Assignment</option>
                  <option value="RETURNED_FROM_LAB">Return to Vault from Crime Lab</option>
                  <option value="RELEASED_TO_OWNER">Release to Verified Property Owner</option>
                  <option value="FINAL_DISPOSITION_DESTROYED">Final Disposition / Authorized Destruction</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Receiving Person Name</label>
                  <input
                    type="text"
                    value={receivedByName}
                    onChange={e => setReceivedByName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Receiving Badge / ID #</label>
                  <input
                    type="text"
                    value={receivedByBadge}
                    onChange={e => setReceivedByBadge(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Agency / Bureau / Lab Division</label>
                <input
                  type="text"
                  value={agencyDivision}
                  onChange={e => setAgencyDivision(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Purpose / Authorized Case Reason</label>
                <textarea
                  rows={3}
                  value={purposeReason}
                  onChange={e => setPurposeReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white leading-relaxed"
                  required
                />
              </div>

              <div className="flex items-center gap-2 p-2.5 bg-slate-950 border border-slate-800 rounded-lg">
                <input
                  type="checkbox"
                  id="tamperSeal"
                  checked={tamperSealIntact}
                  onChange={e => setTamperSealIntact(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="tamperSeal" className="text-slate-300 cursor-pointer">
                  Physical tamper seal verified intact before handover
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-4 py-2 rounded-lg cursor-pointer"
                >
                  Confirm & Seal Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Log New Evidence Modal */}
      {isNewEvidenceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Log New Evidence Item</h3>
              <button
                onClick={() => setIsNewEvidenceModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateEvidence} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Target Incident / Case #</label>
                  <input
                    type="text"
                    value={newIncidentId}
                    onChange={e => setNewIncidentId(e.target.value)}
                    placeholder="2026-PD-08942"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as EvidenceCategory)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  >
                    <option value="WEAPON_FIREARM">Firearm / Weapon</option>
                    <option value="NARCOTICS">Narcotics / Controlled Substance</option>
                    <option value="BIOLOGICAL_DNA">Biological / DNA Sample</option>
                    <option value="DIGITAL_BWC_VIDEO">Digital BWC / Audio / Video</option>
                    <option value="CURRENCY">Currency / Valuables</option>
                    <option value="PROPERTY_IMPOUND">Property / Burglary Tool</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Detailed Item Description</label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  placeholder="Make, model, serial #, markings, caliber, packaging details..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Storage Locker / Bin Location</label>
                <input
                  type="text"
                  value={newStorageLocation}
                  onChange={e => setNewStorageLocation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Recovering Officer</label>
                  <input
                    type="text"
                    value={newOfficer}
                    onChange={e => setNewOfficer(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Badge #</label>
                  <input
                    type="text"
                    value={newBadge}
                    onChange={e => setNewBadge(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsNewEvidenceModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-4 py-2 rounded-lg cursor-pointer"
                >
                  Generate Barcode & Log Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Barcode Label View */}
      {isPrintLabelOpen && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Evidence Label Sticker</h3>
              <button
                onClick={() => setIsPrintLabelOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Label preview box (white card like real sticker) */}
            <div className="bg-white text-black p-5 rounded-lg border-2 border-slate-300 space-y-3 font-mono">
              <div className="border-b border-black pb-2 text-center">
                <div className="font-bold text-xs uppercase tracking-wider">
                  DEPARTMENT PROPERTY & EVIDENCE BUREAU
                </div>
                <div className="text-[10px] text-neutral-600">OFFICIAL EVIDENCE SEAL · DO NOT TAMPER</div>
              </div>

              {/* Barcode Visual Representation */}
              <div className="text-center py-2 bg-slate-100 rounded">
                <div className="text-2xl font-bold tracking-widest uppercase">
                  || | |||| | |||| || || | |||
                </div>
                <div className="font-bold text-sm mt-1">{selectedItem.trackingBarcode}</div>
              </div>

              <div className="text-[11px] space-y-1 font-sans">
                <div><strong>CASE #:</strong> {selectedItem.incidentId}</div>
                <div><strong>CATEGORY:</strong> {selectedItem.category}</div>
                <div><strong>ITEM:</strong> {selectedItem.description}</div>
                <div><strong>DATE RECOVERED:</strong> {new Date(selectedItem.dateCollected).toLocaleDateString()}</div>
                <div><strong>LOCATION:</strong> {selectedItem.storageLockerLocation}</div>
                <div className="text-[9px] font-mono break-all pt-1 text-neutral-600">
                  SHA-256: {selectedItem.sha256Hash.slice(0, 32)}...
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setIsPrintLabelOpen(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => window.print()}
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-4 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Thermal Label</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
