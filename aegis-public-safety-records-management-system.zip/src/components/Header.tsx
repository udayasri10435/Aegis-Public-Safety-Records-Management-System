import React from 'react';
import { useRMS, NavigationTab } from '../context/RMSContext';
import { Plus, ShieldAlert, RotateCcw } from 'lucide-react';
import { AgencyType } from '../types/rms';

interface HeaderProps {
  onOpenNewIncidentModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenNewIncidentModal }) => {
  const {
    activeTab,
    setActiveTab,
    activeAgencyFilter,
    setActiveAgencyFilter,
    cadCalls,
    incidents,
    resetAllData
  } = useRMS();

  const pendingCadCount = cadCalls.filter(c => c.status !== 'TRANSFERRED_TO_RMS').length;
  const reviewNeededCount = incidents.filter(i => i.status === 'SUPERVISOR_REVIEW').length;

  const navItems: { id: NavigationTab; label: string; badge?: number }[] = [
    { id: 'incidents', label: 'Incidents', badge: reviewNeededCount > 0 ? reviewNeededCount : undefined },
    { id: 'cad', label: 'CAD Feed', badge: pendingCadCount > 0 ? pendingCadCount : undefined },
    { id: 'evidence', label: 'Evidence Chain' },
    { id: 'foia', label: 'FOIA Studio' },
    { id: 'master_indices', label: 'Master Indices' },
    { id: 'audit_log', label: 'CJIS Audit' }
  ];

  const agencyOptions: { value: 'ALL' | AgencyType; label: string }[] = [
    { value: 'ALL', label: 'All Services' },
    { value: 'POLICE', label: 'Police (NIBRS)' },
    { value: 'FIRE', label: 'Fire (NFIRS)' },
    { value: 'EMS', label: 'EMS (NEMSIS)' }
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-cyan-600 flex items-center justify-center text-white shadow-inner font-bold text-base">
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
          <button
            onClick={() => setActiveTab('incidents')}
            className="text-lg font-bold tracking-tight text-white hover:text-cyan-400 transition-colors cursor-pointer text-left"
          >
            Aegis Public Safety RMS
          </button>
        </div>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium">
          {navItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative py-1.5 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  isActive
                    ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="text-xs font-mono font-bold text-amber-400">
                    ({item.badge})
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Agency Switcher & Primary Action */}
        <div className="flex items-center gap-3">
          {/* Agency Segmented Filter */}
          <div className="relative">
            <select
              value={activeAgencyFilter}
              onChange={e => setActiveAgencyFilter(e.target.value as any)}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-medium cursor-pointer"
              title="Filter by public safety division"
            >
              {agencyOptions.map(opt => (
                <option key={opt.value} value={opt.value} className="bg-slate-900 text-slate-100">
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* New Incident Primary CTA */}
          <button
            onClick={onOpenNewIncidentModal}
            className="inline-flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 active:bg-cyan-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors shadow-sm whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Incident</span>
          </button>

          {/* Reset Demo Data button (subtle) */}
          <button
            onClick={() => {
              if (window.confirm('Reset all records, evidence, and CAD logs to demo baseline?')) {
                resetAllData();
              }
            }}
            title="Reset system to verified demo baseline"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mobile Nav strip for smaller screens */}
      <div className="lg:hidden flex items-center gap-3 px-4 py-2 border-t border-slate-800/80 overflow-x-auto text-xs bg-slate-950">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`whitespace-nowrap px-2.5 py-1 rounded transition-colors ${
              activeTab === item.id
                ? 'bg-slate-800 text-cyan-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {item.label} {item.badge ? `(${item.badge})` : ''}
          </button>
        ))}
      </div>
    </header>
  );
};
