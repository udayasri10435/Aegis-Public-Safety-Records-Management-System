import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { IncidentReport, AgencyType, InvolvedPerson, InvolvedVehicle } from '../types/rms';
import { X, Plus, Trash2, Shield, Flame, Ambulance, Save, AlertCircle } from 'lucide-react';

interface IncidentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialIncident?: IncidentReport | null;
}

export const IncidentFormModal: React.FC<IncidentFormModalProps> = ({
  isOpen,
  onClose,
  initialIncident
}) => {
  const { createIncident, updateIncident } = useRMS();

  const isEditing = Boolean(initialIncident);

  const [agency, setAgency] = useState<AgencyType>(initialIncident?.agency || 'POLICE');
  const [title, setTitle] = useState(initialIncident?.title || '');
  const [incidentType, setIncidentType] = useState(initialIncident?.incidentType || '');
  const [codeNibrsOrClass, setCodeNibrsOrClass] = useState(initialIncident?.codeNibrsOrClass || '');
  const [locationAddress, setLocationAddress] = useState(initialIncident?.locationAddress || '');
  const [zoneBeat, setZoneBeat] = useState(initialIncident?.zoneBeat || 'Sector 1 / Beat 12');
  const [reportingOfficerName, setReportingOfficerName] = useState(initialIncident?.reportingOfficerName || 'Marcus Vance');
  const [reportingOfficerBadge, setReportingOfficerBadge] = useState(initialIncident?.reportingOfficerBadge || 'PD-4819');
  const [assignedUnit, setAssignedUnit] = useState(initialIncident?.assignedUnit || 'Unit 1-Adam-4');
  const [status, setStatus] = useState<IncidentReport['status']>(initialIncident?.status || 'SUPERVISOR_REVIEW');
  const [narrativeText, setNarrativeText] = useState(initialIncident?.narrativeText || '');

  // Persons
  const [persons, setPersons] = useState<InvolvedPerson[]>(initialIncident?.persons || []);
  const [vehicles, setVehicles] = useState<InvolvedVehicle[]>(initialIncident?.vehicles || []);

  // Fire specific fields
  const [fireEstimatedLoss, setFireEstimatedLoss] = useState(initialIncident?.fireData?.estimatedLossDollars || 0);
  const [fireApparatus, setFireApparatus] = useState(initialIncident?.fireData?.apparatusAssigned.join(', ') || 'Engine 4, Truck 2');
  const [fireCause, setFireCause] = useState(initialIncident?.fireData?.causeOfIgnition || 'Under investigation');

  // EMS specific fields
  const [emsChiefComplaint, setEmsChiefComplaint] = useState(initialIncident?.emsData?.chiefComplaint || '');
  const [emsHospital, setEmsHospital] = useState(initialIncident?.emsData?.transportHospital || 'Memorial Regional Hospital');

  if (!isOpen) return null;

  const handleAddPerson = () => {
    const newPerson: InvolvedPerson = {
      id: `P-${Date.now().toString().slice(-4)}`,
      role: 'WITNESS',
      fullName: '',
      dob: '1990-01-01',
      ssnMasked: '***-**-0000',
      phone: '',
      address: ''
    };
    setPersons([...persons, newPerson]);
  };

  const handleUpdatePerson = (index: number, updates: Partial<InvolvedPerson>) => {
    setPersons(prev => prev.map((p, idx) => (idx === index ? { ...p, ...updates } : p)));
  };

  const handleRemovePerson = (index: number) => {
    setPersons(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleAddVehicle = () => {
    const newVehicle: InvolvedVehicle = {
      id: `V-${Date.now().toString().slice(-4)}`,
      plate: '',
      state: 'CA',
      vin: '',
      make: '',
      model: '',
      year: new Date().getFullYear(),
      color: 'White',
      isStolen: false
    };
    setVehicles([...vehicles, newVehicle]);
  };

  const handleUpdateVehicle = (index: number, updates: Partial<InvolvedVehicle>) => {
    setVehicles(prev => prev.map((v, idx) => (idx === index ? { ...v, ...updates } : v)));
  };

  const handleRemoveVehicle = (index: number) => {
    setVehicles(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !locationAddress.trim()) {
      alert('Please fill in required fields: Incident Title and Location Address.');
      return;
    }

    if (isEditing && initialIncident) {
      updateIncident(initialIncident.id, {
        agency,
        title,
        incidentType: incidentType || title,
        codeNibrsOrClass: codeNibrsOrClass || (agency === 'POLICE' ? 'NIBRS General' : agency === 'FIRE' ? 'NFIRS 100' : 'NEMSIS R07'),
        locationAddress,
        zoneBeat,
        reportingOfficerName,
        reportingOfficerBadge,
        assignedUnit,
        status,
        narrativeText,
        persons,
        vehicles
      });
    } else {
      const year = new Date().getFullYear();
      const code = agency === 'POLICE' ? 'PD' : agency === 'FIRE' ? 'FD' : 'EMS';
      const rand = Math.floor(1000 + Math.random() * 9000);
      const newId = `${year}-${code}-${rand}`;

      const newReport: IncidentReport = {
        id: newId,
        agency,
        title,
        incidentType: incidentType || title,
        codeNibrsOrClass: codeNibrsOrClass || (agency === 'POLICE' ? 'NIBRS 120' : agency === 'FIRE' ? 'NFIRS 111' : 'NEMSIS I21'),
        status,
        occurredFrom: new Date().toISOString(),
        reportedDate: new Date().toISOString(),
        locationAddress,
        zoneBeat,
        reportingOfficerName,
        reportingOfficerBadge,
        assignedUnit,
        narrativeText: narrativeText || 'Initial officer narrative summary entered upon record creation.',
        persons,
        vehicles,
        linkedEvidenceIds: []
      };

      if (agency === 'FIRE') {
        newReport.fireData = {
          nfirsCode: codeNibrsOrClass || '111 - Building Fire',
          alarmTime: new Date().toISOString(),
          arrivalFirstUnit: new Date().toISOString(),
          controlledTime: '',
          clearedTime: '',
          propertyUse: 'General Structure / Commercial',
          detectorPresence: 'ALERTED',
          causeOfIgnition: fireCause,
          estimatedLossDollars: Number(fireEstimatedLoss) || 0,
          apparatusAssigned: fireApparatus.split(',').map(s => s.trim()),
          civilianInjuries: 0,
          firefighterInjuries: 0
        };
      } else if (agency === 'EMS') {
        newReport.emsData = {
          nemsisCode: codeNibrsOrClass || 'R07.9 - Chest Pain',
          chiefComplaint: emsChiefComplaint || 'Emergency medical evaluation',
          initialAcuity: 'EMERGENT_YELLOW',
          vitals: [
            {
              id: 'VIT-01',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              bpSystolic: 120,
              bpDiastolic: 80,
              pulseRate: 72,
              respiratoryRate: 16,
              spo2Percent: 98,
              gcsTotal: 15
            }
          ],
          medicationsAdministered: [],
          interventions: ['Vitals Monitored', 'Patient Evaluation'],
          transportHospital: emsHospital,
          triageCategory: 'Urgent',
          dnrVerified: false
        };
      }

      createIncident(newReport);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-cyan-500/10 text-cyan-400">
              {agency === 'FIRE' ? (
                <Flame className="w-5 h-5 text-rose-400" />
              ) : agency === 'EMS' ? (
                <Ambulance className="w-5 h-5 text-amber-400" />
              ) : (
                <Shield className="w-5 h-5 text-cyan-400" />
              )}
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isEditing ? `Edit Incident: ${initialIncident?.id}` : 'Create Public Safety Incident Report'}
              </h2>
              <p className="text-xs text-slate-400">
                CJIS & National Reporting Standard Compliant (NIBRS / NFIRS / NEMSIS)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Agency & Primary Classification */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Public Safety Division
              </label>
              <select
                value={agency}
                onChange={e => setAgency(e.target.value as AgencyType)}
                disabled={isEditing}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-medium focus:ring-1 focus:ring-cyan-500 focus:outline-none"
              >
                <option value="POLICE">Police (Law Enforcement - NIBRS)</option>
                <option value="FIRE">Fire & Rescue (NFIRS 5.0)</option>
                <option value="EMS">Emergency Medical (NEMSIS v3.5)</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-300 mb-1.5">
                Official Incident Title
              </label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Commercial Armed Robbery, 2nd Alarm Warehouse Fire..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Offense Code, Location, Zone */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                {agency === 'POLICE'
                  ? 'NIBRS Offense Classification'
                  : agency === 'FIRE'
                  ? 'NFIRS Incident Code'
                  : 'NEMSIS Complaint Code'}
              </label>
              <input
                type="text"
                value={codeNibrsOrClass}
                onChange={e => setCodeNibrsOrClass(e.target.value)}
                placeholder={
                  agency === 'POLICE'
                    ? 'e.g. 120 - Robbery'
                    : agency === 'FIRE'
                    ? 'e.g. 111 - Building fire'
                    : 'e.g. I21.0 - Acute STEMI'
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono placeholder-slate-500 focus:ring-1 focus:ring-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Incident Location Address
              </label>
              <input
                type="text"
                value={locationAddress}
                onChange={e => setLocationAddress(e.target.value)}
                placeholder="Street address, Suite / Floor..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Zone / Beat / Sector
              </label>
              <input
                type="text"
                value={zoneBeat}
                onChange={e => setZoneBeat(e.target.value)}
                placeholder="Sector 4 / Beat 42"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:ring-1 focus:ring-cyan-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Reporting Officer & Approval Status */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Reporting Officer Name
              </label>
              <input
                type="text"
                value={reportingOfficerName}
                onChange={e => setReportingOfficerName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Officer Badge #
              </label>
              <input
                type="text"
                value={reportingOfficerBadge}
                onChange={e => setReportingOfficerBadge(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Assigned Unit
              </label>
              <input
                type="text"
                value={assignedUnit}
                onChange={e => setAssignedUnit(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1.5">
                Supervisory Workflow Status
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-medium focus:outline-none"
              >
                <option value="DRAFT">Draft</option>
                <option value="SUPERVISOR_REVIEW">Supervisor Review Required</option>
                <option value="APPROVED">Approved & CJIS Sealed</option>
              </select>
            </div>
          </div>

          {/* Agency Specific Data Blocks */}
          {agency === 'FIRE' && (
            <div className="p-4 bg-slate-950/70 border border-rose-900/40 rounded-xl space-y-3">
              <h3 className="font-bold text-rose-400 uppercase tracking-wide text-xs">
                NFIRS Fire Incident Extension
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Estimated Loss ($)</label>
                  <input
                    type="number"
                    value={fireEstimatedLoss}
                    onChange={e => setFireEstimatedLoss(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Apparatus Assigned</label>
                  <input
                    type="text"
                    value={fireApparatus}
                    onChange={e => setFireApparatus(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Cause of Ignition</label>
                  <input
                    type="text"
                    value={fireCause}
                    onChange={e => setFireCause(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {agency === 'EMS' && (
            <div className="p-4 bg-slate-950/70 border border-amber-900/40 rounded-xl space-y-3">
              <h3 className="font-bold text-amber-400 uppercase tracking-wide text-xs">
                NEMSIS ePCR Extension
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Chief Complaint</label>
                  <input
                    type="text"
                    value={emsChiefComplaint}
                    onChange={e => setEmsChiefComplaint(e.target.value)}
                    placeholder="e.g. Substernal crushing chest pain, dyspnea..."
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Transport Hospital</label>
                  <input
                    type="text"
                    value={emsHospital}
                    onChange={e => setEmsHospital(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Involved Persons Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-300 uppercase tracking-wide text-xs">
                Involved Persons ({persons.length})
              </h3>
              <button
                type="button"
                onClick={handleAddPerson}
                className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Person</span>
              </button>
            </div>

            {persons.map((person, idx) => (
              <div
                key={person.id || idx}
                className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-cyan-400 font-bold">#{idx + 1}</span>
                    <select
                      value={person.role}
                      onChange={e => handleUpdatePerson(idx, { role: e.target.value as any })}
                      className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-2 py-1"
                    >
                      <option value="SUSPECT">Suspect</option>
                      <option value="VICTIM">Victim</option>
                      <option value="WITNESS">Witness</option>
                      <option value="REPORTING_PARTY">Reporting Party</option>
                      <option value="PATIENT">Patient</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemovePerson(idx)}
                    className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <input
                    type="text"
                    value={person.fullName}
                    onChange={e => handleUpdatePerson(idx, { fullName: e.target.value })}
                    placeholder="Full Name..."
                    className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                  />
                  <input
                    type="date"
                    value={person.dob}
                    onChange={e => handleUpdatePerson(idx, { dob: e.target.value })}
                    className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white font-mono"
                  />
                  <input
                    type="text"
                    value={person.phone}
                    onChange={e => handleUpdatePerson(idx, { phone: e.target.value })}
                    placeholder="Phone Number..."
                    className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                  />
                  <input
                    type="text"
                    value={person.address}
                    onChange={e => handleUpdatePerson(idx, { address: e.target.value })}
                    placeholder="Address..."
                    className="bg-slate-900 border border-slate-800 rounded p-1.5 text-white"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Officer Narrative Chronology */}
          <div className="space-y-1.5">
            <label className="block font-bold text-slate-300 uppercase tracking-wide text-xs">
              Officer Chronological Narrative & Probable Cause Synopsis
            </label>
            <textarea
              rows={8}
              value={narrativeText}
              onChange={e => setNarrativeText(e.target.value)}
              placeholder="Enter detailed chronological account of incident, observations, evidence recovered, statements taken..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white font-mono text-xs leading-relaxed focus:outline-none focus:ring-1 focus:ring-cyan-500"
              required
            />
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-5 py-2 rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isEditing ? 'Save Changes' : 'Submit Incident Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
