import React, { useState } from 'react';
import { useRMS } from '../context/RMSContext';
import { IncidentReport, AgencyType } from '../types/rms';
import {
  Search,
  Filter,
  Eye,
  CheckCircle,
  Clock,
  Printer,
  FileLock2,
  Shield,
  Flame,
  Ambulance,
  Lock,
  Edit3
} from 'lucide-react';

interface IncidentsListViewProps {
  onSelectIncident: (incident: IncidentReport) => void;
  onOpenPrintModal: (incident: IncidentReport) => void;
  onOpenEditModal: (incident: IncidentReport) => void;
}

export const IncidentsListView: React.FC<IncidentsListViewProps> = ({
  onSelectIncident,
  onOpenPrintModal,
  onOpenEditModal
}) => {
  const {
    incidents,
    activeAgencyFilter,
    setActiveAgencyFilter,
    approveIncident
  } = useRMS();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Filtered incidents
  const filteredIncidents = incidents.filter(inc => {
    // Agency Filter
    if (activeAgencyFilter !== 'ALL' && inc.agency !== activeAgencyFilter) {
      return false;
    }
    // Status Filter
    if (statusFilter !== 'ALL' && inc.status !== statusFilter) {
      return false;
    }
    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inId = inc.id.toLowerCase().includes(q);
      const inTitle = inc.title.toLowerCase().includes(q);
      const inType = inc.incidentType.toLowerCase().includes(q);
      const inLoc = inc.locationAddress.toLowerCase().includes(q);
      const inOfficer = inc.reportingOfficerName.toLowerCase().includes(q) || inc.reportingOfficerBadge.toLowerCase().includes(q);
      const inPersons = inc.persons.some(p => p.fullName.toLowerCase().includes(q));
      return inId || inTitle || inType || inLoc || inOfficer || inPersons;
    }
    return true;
  });

  const counts = {
    total: incidents.length,
    review: incidents.filter(i => i.status === 'SUPERVISOR_REVIEW').length,
    approved: incidents.filter(i => i.status === 'APPROVED').length,
    police: incidents.filter(i => i.agency === 'POLICE').length,
    fire: incidents.filter(i => i.agency === 'FIRE').length,
    ems: incidents.filter(i => i.agency === 'EMS').length
  };

  const handleQuickApprove = (e: React.MouseEvent, inc: IncidentReport) => {
    e.stopPropagation();
    approveIncident(inc.id, 'Sgt. Elena Rodriguez', 'PD-1102');
  };

  return (
    <div className="space-y-6">
      {/* Metrics Row (Structured, single elevation, clean typography) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Total Cases Logged</div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            {counts.total}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Police: {counts.police} · Fire: {counts.fire} · EMS: {counts.ems}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-amber-400 font-medium flex items-center justify-between">
            <span>Supervisor Review Required</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
            {counts.review}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Pending approval & sign-off</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-emerald-400 font-medium flex items-center justify-between">
            <span>Approved & CJIS Cleared</span>
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {counts.approved}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Ready for court & archive</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-cyan-400 font-medium flex items-center justify-between">
            <span>Standards Compliance</span>
            <FileLock2 className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-sm font-bold font-mono text-white mt-2">
            NIBRS · NFIRS · NEMSIS
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Federal reporting automated</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by Case #, Person, Offense (e.g. Robbery), Location, Badge..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Status Filter Segmented Buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg text-xs shrink-0 overflow-x-auto">
            {['ALL', 'SUPERVISOR_REVIEW', 'APPROVED', 'DRAFT'].map(status => (
              <button
                key={status}
                type="button"
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  statusFilter === status
                    ? 'bg-slate-800 text-cyan-400 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {status === 'ALL'
                  ? 'All Statuses'
                  : status === 'SUPERVISOR_REVIEW'
                  ? 'Review Queue'
                  : status === 'APPROVED'
                  ? 'Approved'
                  : 'Drafts'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Incident Records Table / Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="divide-y divide-slate-800">
          {filteredIncidents.map(inc => {
            return (
              <div
                key={inc.id}
                onClick={() => onSelectIncident(inc)}
                className="p-4 sm:p-5 hover:bg-slate-850 transition-colors cursor-pointer text-left group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  {/* Left: Agency, Case ID, Title */}
                  <div className="flex items-start sm:items-center gap-3">
                    <div
                      className={`p-2 rounded-lg shrink-0 ${
                        inc.agency === 'POLICE'
                          ? 'bg-cyan-500/10 text-cyan-400'
                          : inc.agency === 'FIRE'
                          ? 'bg-rose-500/10 text-rose-400'
                          : 'bg-amber-500/10 text-amber-400'
                      }`}
                    >
                      {inc.agency === 'POLICE' ? (
                        <Shield className="w-4 h-4" />
                      ) : inc.agency === 'FIRE' ? (
                        <Flame className="w-4 h-4" />
                      ) : (
                        <Ambulance className="w-4 h-4" />
                      )}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-mono font-bold text-white">{inc.id}</span>
                        <span className="text-slate-600">·</span>
                        <span className="text-slate-400">{inc.codeNibrsOrClass}</span>
                        {inc.cadCallId && (
                          <>
                            <span className="text-slate-600">·</span>
                            <span className="font-mono text-cyan-400 text-[11px]">
                              CAD {inc.cadCallId}
                            </span>
                          </>
                        )}
                      </div>
                      <h2 className="text-sm font-semibold text-slate-200 mt-0.5 group-hover:text-cyan-400 transition-colors">
                        {inc.title}
                      </h2>
                    </div>
                  </div>

                  {/* Right: Status and Actions */}
                  <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                    {/* Status Text (Zero-pill text styling) */}
                    <div className="text-right text-xs">
                      {inc.status === 'APPROVED' ? (
                        <span className="text-emerald-400 font-medium flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" /> Approved / CJIS Sealed
                        </span>
                      ) : inc.status === 'SUPERVISOR_REVIEW' ? (
                        <span className="text-amber-400 font-medium flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> Supervisor Review
                        </span>
                      ) : (
                        <span className="text-slate-400 font-medium">
                          Draft (Open)
                        </span>
                      )}
                    </div>

                    {/* Quick Action Buttons */}
                    <div className="flex items-center gap-1.5">
                      {inc.status === 'SUPERVISOR_REVIEW' && (
                        <button
                          type="button"
                          onClick={e => handleQuickApprove(e, inc)}
                          title="Supervisory Approval Sign-off"
                          className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs px-2.5 py-1 rounded transition-colors cursor-pointer"
                        >
                          Approve
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onOpenEditModal(inc);
                        }}
                        title="Edit Incident Details"
                        className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onOpenPrintModal(inc);
                        }}
                        title="Print / Export Official CJIS Record"
                        className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Subtitle / Details row with clean unboxed text and dot separators */}
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-2.5 pt-2 border-t border-slate-800/60 font-sans">
                  <span>Location: {inc.locationAddress}</span>
                  <span className="text-slate-600">·</span>
                  <span>Zone: {inc.zoneBeat}</span>
                  <span className="text-slate-600">·</span>
                  <span>
                    Officer: {inc.reportingOfficerName} ({inc.reportingOfficerBadge})
                  </span>
                  <span className="text-slate-600">·</span>
                  <span className="font-mono tabular-nums">
                    {new Date(inc.reportedDate).toLocaleDateString()} {new Date(inc.reportedDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {inc.persons.length > 0 && (
                    <>
                      <span className="text-slate-600">·</span>
                      <span>
                        {inc.persons.length} Person(s) logged
                      </span>
                    </>
                  )}
                  {inc.linkedEvidenceIds.length > 0 && (
                    <>
                      <span className="text-slate-600">·</span>
                      <span className="text-cyan-400 font-mono">
                        {inc.linkedEvidenceIds.length} Evidence Item(s)
                      </span>
                    </>
                  )}
                </div>
              </div>
            );
          })}

          {filteredIncidents.length === 0 && (
            <div className="p-12 text-center text-slate-400 text-xs">
              No incident records found matching the active search or filters.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
